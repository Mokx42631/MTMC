// MCMT v7 — Mokx's Character Management Tool
// D&D 5e (2014) · Pure client-side SPA
// Changes from v6: Tab restructure, spell detail popups, rules enforcement, PDF fix, UI cleanup

// ==================== STORAGE ====================
const STORAGE_KEY = 'mcmt_characters';
function loadCharacters() { try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; } catch { return []; } }
function saveCharacters(chars) { localStorage.setItem(STORAGE_KEY, JSON.stringify(chars)); }
function getCharacter(id) { return loadCharacters().find(c => c.id === id); }
function saveCharacter(char) {
    const chars = loadCharacters();
    const idx = chars.findIndex(c => c.id === char.id);
    char.updatedAt = new Date().toISOString();
    if (idx >= 0) chars[idx] = char; else chars.push(char);
    saveCharacters(chars);
}
function deleteCharacter(id) { saveCharacters(loadCharacters().filter(c => c.id !== id)); }
function newCharId() { return 'char_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6); }

// ==================== SPELL SLOT TABLES ====================
const FULL_CASTER_SLOTS = {
    1:[2,0,0,0,0,0,0,0,0],2:[3,0,0,0,0,0,0,0,0],3:[4,2,0,0,0,0,0,0,0],4:[4,3,0,0,0,0,0,0,0],
    5:[4,3,2,0,0,0,0,0,0],6:[4,3,3,0,0,0,0,0,0],7:[4,3,3,1,0,0,0,0,0],8:[4,3,3,2,0,0,0,0,0],
    9:[4,3,3,3,1,0,0,0,0],10:[4,3,3,3,2,0,0,0,0],11:[4,3,3,3,2,1,0,0,0],12:[4,3,3,3,2,1,0,0,0],
    13:[4,3,3,3,2,1,1,0,0],14:[4,3,3,3,2,1,1,0,0],15:[4,3,3,3,2,1,1,1,0],16:[4,3,3,3,2,1,1,1,0],
    17:[4,3,3,3,2,1,1,1,1],18:[4,3,3,3,3,1,1,1,1],19:[4,3,3,3,3,2,1,1,1],20:[4,3,3,3,3,2,2,1,1]
};
const HALF_CASTER_SLOTS = {
    1:[0,0,0,0,0,0,0,0,0],2:[2,0,0,0,0,0,0,0,0],3:[3,0,0,0,0,0,0,0,0],4:[3,0,0,0,0,0,0,0,0],
    5:[4,2,0,0,0,0,0,0,0],6:[4,2,0,0,0,0,0,0,0],7:[4,3,0,0,0,0,0,0,0],8:[4,3,0,0,0,0,0,0,0],
    9:[4,3,2,0,0,0,0,0,0],10:[4,3,2,0,0,0,0,0,0],11:[4,3,3,0,0,0,0,0,0],12:[4,3,3,0,0,0,0,0,0],
    13:[4,3,3,1,0,0,0,0,0],14:[4,3,3,1,0,0,0,0,0],15:[4,3,3,2,0,0,0,0,0],16:[4,3,3,2,0,0,0,0,0],
    17:[4,3,3,3,1,0,0,0,0],18:[4,3,3,3,1,0,0,0,0],19:[4,3,3,3,2,0,0,0,0],20:[4,3,3,3,2,0,0,0,0]
};
const THIRD_CASTER_SLOTS = {
    1:[0,0,0,0,0,0,0,0,0],2:[0,0,0,0,0,0,0,0,0],3:[2,0,0,0,0,0,0,0,0],4:[3,0,0,0,0,0,0,0,0],
    5:[3,0,0,0,0,0,0,0,0],6:[3,0,0,0,0,0,0,0,0],7:[4,2,0,0,0,0,0,0,0],8:[4,2,0,0,0,0,0,0,0],
    9:[4,2,0,0,0,0,0,0,0],10:[4,3,0,0,0,0,0,0,0],11:[4,3,0,0,0,0,0,0,0],12:[4,3,0,0,0,0,0,0,0],
    13:[4,3,2,0,0,0,0,0,0],14:[4,3,2,0,0,0,0,0,0],15:[4,3,2,0,0,0,0,0,0],16:[4,3,3,0,0,0,0,0,0],
    17:[4,3,3,0,0,0,0,0,0],18:[4,3,3,0,0,0,0,0,0],19:[4,3,3,1,0,0,0,0,0],20:[4,3,3,1,0,0,0,0,0]
};
const PACT_SLOTS = {
    1:[1,1],2:[2,1],3:[2,2],4:[2,2],5:[2,3],6:[2,3],7:[2,4],8:[2,4],
    9:[2,5],10:[2,5],11:[3,5],12:[3,5],13:[3,5],14:[3,5],15:[3,5],16:[3,5],
    17:[4,5],18:[4,5],19:[4,5],20:[4,5]
};


// ==================== MULTICLASS PREREQUISITES (2014 PHB) ====================
const MULTICLASS_PREREQS = {
    Barbarian: {str:13},
    Bard: {cha:13},
    Cleric: {wis:13},
    Druid: {wis:13},
    Fighter: {str:13}, // or dex:13
    Monk: {dex:13, wis:13},
    Paladin: {str:13, cha:13},
    Ranger: {dex:13, wis:13},
    Rogue: {dex:13},
    Sorcerer: {cha:13},
    Warlock: {cha:13},
    Wizard: {int:13},
    Artificer: {int:13},
};
// Fighter/Ranger have OR conditions
const MULTICLASS_PREREQS_OR = {
    Fighter: [{str:13},{dex:13}],
    Ranger: [{dex:13,wis:13}],
};

const MULTICLASS_PROFICIENCIES = {
    Barbarian: {armor:['Shield'],weapons:['Simple weapons','Martial weapons'],tools:[]},
    Bard: {armor:['Light armor'],weapons:[],tools:['One musical instrument']},
    Cleric: {armor:['Light armor','Medium armor','Shield'],weapons:[],tools:[]},
    Druid: {armor:['Light armor','Medium armor','Shield'],weapons:[],tools:[]},
    Fighter: {armor:['Light armor','Medium armor','Shield'],weapons:['Simple weapons','Martial weapons'],tools:[]},
    Monk: {armor:[],weapons:['Simple weapons','Shortsword'],tools:[]},
    Paladin: {armor:['Light armor','Medium armor','Shield'],weapons:['Simple weapons','Martial weapons'],tools:[]},
    Ranger: {armor:['Light armor','Medium armor','Shield'],weapons:['Simple weapons','Martial weapons'],tools:[]},
    Rogue: {armor:['Light armor'],weapons:[],tools:["Thieves' tools"]},
    Sorcerer: {armor:[],weapons:[],tools:[]},
    Warlock: {armor:['Light armor'],weapons:['Simple weapons'],tools:[]},
    Wizard: {armor:[],weapons:[],tools:[]},
    Artificer: {armor:['Light armor','Medium armor','Shield'],weapons:[],tools:["Thieves' tools"]},
};

// Caster level multipliers for multiclass spell slot calculation
const CASTER_LEVEL_MULT = {
    full: 1, '1/2': 0.5, half: 0.5, '1/3': 1/3, third: 1/3, pact: 0, none: 0
};

function getMulticlassCasterLevel(char) {
    if (!char.classLevels) return 0;
    let total = 0;
    for (const [cls, lvl] of Object.entries(char.classLevels)) {
        const classData = CLASSES.find(c => c.name === cls);
        if (!classData) continue;
        const prog = classData.casterProgression || 'none';
        const mult = CASTER_LEVEL_MULT[prog] || 0;
        if (mult > 0) {
            if (mult === 0.5) total += Math.floor(lvl / 2);
            else if (mult < 0.5) total += Math.floor(lvl / 3);
            else total += lvl;
        }
    }
    return total;
}

function meetsMulticlassPrereqs(char, className) {
    // Must meet prereqs of CURRENT class(es) AND new class
    const classesToCheck = [className];
    if (char.classLevels) {
        for (const cls of Object.keys(char.classLevels)) classesToCheck.push(cls);
    } else if (char.charClass) {
        classesToCheck.push(char.charClass);
    }
    for (const cls of classesToCheck) {
        if (cls === className || char.classLevels?.[cls]) {
            // Check this class prereqs
            const orReqs = MULTICLASS_PREREQS_OR[cls];
            if (orReqs) {
                const meetsAny = orReqs.some(req => {
                    return Object.entries(req).every(([ab, min]) => {
                        const full = AB_FROM_SHORT[ab] || ab;
                        return (char[full] || 10) >= min;
                    });
                });
                if (!meetsAny) return {ok:false, reason:`Does not meet ${cls} multiclass prerequisites`};
            } else {
                const reqs = MULTICLASS_PREREQS[cls];
                if (reqs) {
                    for (const [ab, min] of Object.entries(reqs)) {
                        const full = AB_FROM_SHORT[ab] || ab;
                        if ((char[full] || 10) < min) return {ok:false, reason:`${cls} requires ${ab.toUpperCase()} ${min} (you have ${char[full]||10})`};
                    }
                }
            }
        }
    }
    return {ok:true};
}

// ==================== CLASS FEATURES BY LEVEL (2014 PHB) ====================
const CLASS_FEATURES = {
    Barbarian: {
        1:['Rage','Unarmored Defense'],2:['Reckless Attack','Danger Sense'],3:['Primal Path','Primal Path feature'],
        4:['ASI'],5:['Extra Attack','Fast Movement'],6:['Path feature'],7:['Feral Instinct'],
        8:['ASI'],9:['Brutal Critical (1 die)'],10:['Path feature'],11:['Relentless Rage'],
        12:['ASI'],13:['Brutal Critical (2 dice)'],14:['Path feature'],15:['Persistent Rage'],
        16:['ASI'],17:['Brutal Critical (3 dice)'],18:['Indomitable Might'],19:['ASI'],20:['Primal Champion']
    },
    Bard: {
        1:['Spellcasting','Bardic Inspiration (d6)'],2:['Jack of All Trades','Song of Rest (d6)'],3:['Bard College','Bard College feature','Expertise'],
        4:['ASI'],5:['Bardic Inspiration (d8)','Font of Inspiration'],6:['Countercharm','Bard College feature'],
        7:[],8:['ASI'],9:['Song of Rest (d8)'],10:['Bardic Inspiration (d10)','Expertise','Magical Secrets'],
        11:[],12:['ASI','Song of Rest (d10)'],13:[],14:['Magical Secrets','Bard College feature'],
        15:['Bardic Inspiration (d12)'],16:['ASI'],17:['Song of Rest (d12)'],18:['Magical Secrets'],
        19:['ASI'],20:['Superior Inspiration']
    },
    Cleric: {
        1:['Spellcasting','Divine Domain','Divine Domain feature'],2:['Channel Divinity (1/rest)','Divine Domain feature'],
        3:[],4:['ASI'],5:['Destroy Undead (CR 1/2)'],6:['Channel Divinity (2/rest)','Divine Domain feature'],
        7:[],8:['ASI','Destroy Undead (CR 1)','Divine Domain feature'],9:[],10:['Divine Intervention'],
        11:['Destroy Undead (CR 2)'],12:['ASI'],13:[],14:['Destroy Undead (CR 3)'],
        15:[],16:['ASI'],17:['Destroy Undead (CR 4)','Divine Domain feature'],18:['Channel Divinity (3/rest)'],
        19:['ASI'],20:['Divine Intervention improvement']
    },
    Druid: {
        1:['Druidic','Spellcasting'],2:['Wild Shape','Druid Circle','Druid Circle feature'],
        3:[],4:['ASI','Wild Shape improvement'],5:[],6:['Druid Circle feature'],
        7:[],8:['ASI','Wild Shape improvement'],9:[],10:['Druid Circle feature'],
        11:[],12:['ASI'],13:[],14:['Druid Circle feature'],
        15:[],16:['ASI'],17:[],18:['Timeless Body','Beast Spells'],
        19:['ASI'],20:['Archdruid']
    },
    Fighter: {
        1:['Fighting Style','Second Wind'],2:['Action Surge (1)'],3:['Martial Archetype','Martial Archetype feature'],
        4:['ASI'],5:['Extra Attack'],6:['ASI'],7:['Martial Archetype feature'],
        8:['ASI'],9:['Indomitable (1)'],10:['Martial Archetype feature'],11:['Extra Attack (2)'],
        12:['ASI'],13:['Indomitable (2)'],14:['ASI'],15:['Martial Archetype feature'],
        16:['ASI'],17:['Action Surge (2)','Indomitable (3)'],18:['Martial Archetype feature'],
        19:['ASI'],20:['Extra Attack (3)']
    },
    Monk: {
        1:['Unarmored Defense','Martial Arts'],2:['Ki','Unarmored Movement'],3:['Monastic Tradition','Monastic Tradition feature','Deflect Missiles'],
        4:['ASI','Slow Fall'],5:['Extra Attack','Stunning Strike'],6:['Ki-Empowered Strikes','Monastic Tradition feature'],
        7:['Evasion','Stillness of Mind'],8:['ASI'],9:['Unarmored Movement improvement'],
        10:['Purity of Body'],11:['Monastic Tradition feature'],12:['ASI'],
        13:['Tongue of the Sun and Moon'],14:['Diamond Soul'],15:['Timeless Body'],
        16:['ASI'],17:['Monastic Tradition feature'],18:['Empty Body'],19:['ASI'],20:['Perfect Self']
    },
    Paladin: {
        1:['Divine Sense','Lay on Hands'],2:['Fighting Style','Spellcasting','Divine Smite'],
        3:['Divine Health','Sacred Oath','Sacred Oath feature'],4:['ASI'],5:['Extra Attack'],
        6:['Aura of Protection'],7:['Sacred Oath feature'],8:['ASI'],9:[],
        10:['Aura of Courage'],11:['Improved Divine Smite'],12:['ASI'],
        13:[],14:['Cleansing Touch'],15:['Sacred Oath feature'],16:['ASI'],
        17:[],18:['Aura improvements'],19:['ASI'],20:['Sacred Oath feature']
    },
    Ranger: {
        1:['Favored Enemy','Natural Explorer'],2:['Fighting Style','Spellcasting'],
        3:['Ranger Archetype','Ranger Archetype feature','Primeval Awareness'],4:['ASI'],
        5:['Extra Attack'],6:['Favored Enemy improvement','Natural Explorer improvement'],
        7:['Ranger Archetype feature'],8:['ASI',"Land's Stride"],9:[],10:['Hide in Plain Sight','Natural Explorer improvement'],
        11:['Ranger Archetype feature'],12:['ASI'],13:[],14:['Vanish'],
        15:['Ranger Archetype feature'],16:['ASI'],17:[],18:['Feral Senses'],
        19:['ASI'],20:['Foe Slayer']
    },
    Rogue: {
        1:['Expertise','Sneak Attack (1d6)','Thieves\'Cant'],2:['Cunning Action'],
        3:['Roguish Archetype','Roguish Archetype feature','Sneak Attack (2d6)'],4:['ASI'],
        5:['Uncanny Dodge','Sneak Attack (3d6)'],6:['Expertise'],
        7:['Evasion','Sneak Attack (4d6)'],8:['ASI'],9:['Roguish Archetype feature','Sneak Attack (5d6)'],
        10:['ASI'],11:['Reliable Talent','Sneak Attack (6d6)'],12:['ASI'],
        13:['Roguish Archetype feature','Sneak Attack (7d6)'],14:['Blindsense'],
        15:['Slippery Mind','Sneak Attack (8d6)'],16:['ASI'],
        17:['Roguish Archetype feature','Sneak Attack (9d6)'],18:['Elusive'],
        19:['ASI','Sneak Attack (10d6)'],20:['Stroke of Luck']
    },
    Sorcerer: {
        1:['Spellcasting','Sorcerous Origin','Sorcerous Origin feature'],2:['Font of Magic'],
        3:['Metamagic'],4:['ASI'],5:[],6:['Sorcerous Origin feature'],
        7:[],8:['ASI'],9:[],10:['Metamagic'],
        11:[],12:['ASI'],13:[],14:['Sorcerous Origin feature'],
        15:[],16:['ASI'],17:['Metamagic'],18:['Sorcerous Origin feature'],
        19:['ASI'],20:['Sorcerous Restoration']
    },
    Warlock: {
        1:['Pact Magic','Otherworldly Patron','Otherworldly Patron feature'],2:['Eldritch Invocations'],
        3:['Pact Boon'],4:['ASI'],5:[],6:['Otherworldly Patron feature'],
        7:[],8:['ASI'],9:[],10:['Otherworldly Patron feature'],
        11:['Mystic Arcanum (6th level)'],12:['ASI'],13:['Mystic Arcanum (7th level)'],
        14:['Otherworldly Patron feature'],15:['Mystic Arcanum (8th level)'],16:['ASI'],
        17:['Mystic Arcanum (9th level)'],18:[],19:['ASI'],20:['Eldritch Master']
    },
    Wizard: {
        1:['Spellcasting','Arcane Recovery'],2:['Arcane Tradition','Arcane Tradition feature'],
        3:[],4:['ASI'],5:[],6:['Arcane Tradition feature'],
        7:[],8:['ASI'],9:[],10:['Arcane Tradition feature'],
        11:[],12:['ASI'],13:[],14:['Arcane Tradition feature'],
        15:[],16:['ASI'],17:[],18:['Spell Mastery'],
        19:['ASI'],20:['Signature Spells']
    },
    Artificer: {
        1:['Magical Tinkering','Spellcasting'],2:['Infuse Item'],
        3:['Artificer Specialist','Artificer Specialist feature','The Right Tool for the Job'],4:['ASI'],
        5:['Artificer Specialist feature'],6:['Tool Expertise'],7:['Flash of Genius'],
        8:['ASI'],9:['Artificer Specialist feature'],10:['Magic Item Adept'],
        11:['Spell-Storing Item'],12:['ASI'],13:[],14:['Magic Item Savant','Artificer Specialist feature'],
        15:[],16:['ASI'],17:[],18:['Magic Item Master'],
        19:['ASI'],20:['Soul of Artifice']
    }
};

// Background feat mapping (2024 backgrounds give a feat at level 1)
const BACKGROUND_FEATS = {
    Acolyte:'Magic Initiate (Cleric)',
    Charlatan:'Skilled',
    Criminal:'Alert',
    Entertainer:'Musician',
    'Folk Hero':'Savage Attacker',
    'Guild Artisan':'Crafter',
    Hermit:'Healer',
    Noble:'Skilled',
    Outlander:'Tough',
    Sage:'Magic Initiate (Wizard)',
    Sailor:'Tavern Brawler',
    Soldier:'Savage Attacker',
    Urchin:'Lucky',
};

function getClassFeaturesAtLevel(className, level) {
    const features = CLASS_FEATURES[className];
    if (!features) return [];
    return features[level] || [];
}

function getLevelUpSummary(className, level, subclass) {
    const features = getClassFeaturesAtLevel(className, level);
    const result = [];
    for (const f of features) {
        if (f === 'ASI') {
            result.push({type:'asi', label:'Ability Score Improvement or Feat'});
        } else if (f.includes('feature') && subclass) {
            result.push({type:'subclass_feature', label:`${subclass} feature`});
        } else {
            result.push({type:'feature', label:f});
        }
    }
    return result;
}

function getSpellSlotsForClass(className, level) {
    const cls = CLASSES.find(c => c.name === className);
    if (!cls) return null;
    const prog = cls.casterProgression;
    if (prog === 'full') return FULL_CASTER_SLOTS[level];
    if (prog === 'half' || prog === '1/2') return HALF_CASTER_SLOTS[level];
    if (prog === 'third' || prog === '1/3') return THIRD_CASTER_SLOTS[level];
    if (prog === 'pact') return null;
    return null;
}

const CLASS_SPELL_ABILITY = {
    Bard:'cha',Cleric:'wis',Druid:'wis',Paladin:'cha',Ranger:'wis',
    Sorcerer:'cha',Warlock:'cha',Wizard:'int',Artificer:'int'
};
const PREPARED_CASTERS = ['Cleric','Druid','Paladin'];
const KNOWN_CASTERS = ['Bard','Ranger','Sorcerer','Warlock','Wizard'];

// ==================== RULES: Proficiency by Level (2014 PHB) ====================
function profBonusByLevel(level) { return Math.ceil(level / 4) + 1; }

// ==================== RULES: Skill proficiency budget ====================
// Returns max number of skill proficiencies allowed from class + race + background
function getMaxSkillProficiencies(char) {
    let max = 0;
    const cls = CLASSES.find(c => c.name === char.charClass);
    if (cls && cls.startingProficiencies && cls.startingProficiencies.skills) {
        const sk = cls.startingProficiencies.skills[0];
        if (sk && sk.choose) max += sk.choose.count || 0;
    }
    // Background typically grants 2 skill proficiencies
    if (char.background) max += 2;
    // Race bonuses: some races grant extra skill profs (half-elf gets 2, etc.)
    const race = RACES.find(r => r.name === char.race);
    if (race) {
        if (race.skillProficiencies) {
            for (const sp of race.skillProficiencies) {
                if (sp.choose) max += sp.choose.count || 0;
                else max += Object.keys(sp).filter(k => k !== 'choose' && k !== 'any').length;
                if (sp.any) max += sp.any;
            }
        }
        // Half-Elf specific: 2 free skills
        if (char.race === 'Half-Elf') max += 2;
    }
    return max || 4; // fallback minimum
}

// ==================== RULES: Ability Score budget enforcement ====================
function getMaxAbilityTotal(char) {
    // Standard array total = 72, Point buy max total = 75 (all 15s)
    // With racial bonuses: typically +3 to +5 total
    const race = RACES.find(r => r.name === char.race);
    let racialTotal = 0;
    if (race && race.ability && race.ability.length) {
        for (const ab of race.ability) {
            for (const [k, v] of Object.entries(ab)) racialTotal += v;
        }
    }
    // Max base total via point buy is 75; standard array is 72
    return 75 + racialTotal;
}

function getCurrentAbilityTotal(char) {
    return (char.strength||10) + (char.dexterity||10) + (char.constitution||10) +
           (char.intelligence||10) + (char.wisdom||10) + (char.charisma||10);
}

// ==================== DEFAULT CHARACTER ====================
function defaultCharacter() {
    return {
        id: newCharId(), name: 'New Character', portraitImage: '',
        race: '', subrace: '', charClass: '', subclass: '',
        level: 1, background: '', alignment: '', xp: 0, playerName: '',
        strength: 10, dexterity: 10, constitution: 10, intelligence: 10, wisdom: 10, charisma: 10,
        abilityScoreLocked: false, skillsLocked: false,
        ac: 10, initiative: 0, speed: 30,
        hpMax: 10, hpCurrent: 10, hpTemp: 0,
        hitDice: '1d10', hitDiceRemaining: 1,
        profBonus: 2, inspiration: 0, passivePerception: 10,
        deathSuccess: [false, false, false], deathFail: [false, false, false],
        saveProficiency: { str:false, dex:false, con:false, int:false, wis:false, cha:false },
        skills: {
            acrobatics:0,animalHandling:0,arcana:0,athletics:0,deception:0,history:0,
            insight:0,intimidation:0,investigation:0,medicine:0,nature:0,perception:0,
            performance:0,persuasion:0,religion:0,sleightOfHand:0,stealth:0,survival:0,
        },
        personalityTraits:'',ideals:'',bonds:'',flaws:'',
        featuresTraits:'',proficienciesLanguages:'',
        attacksSpellcasting:'',equipment:'',notes:'',
        cp:0,sp:0,ep:0,gp:0,pp:0,
        age:'',height:'',weight:'',eyes:'',skin:'',hair:'',
        appearance:'',backstory:'',alliesOrgs:'',
        spellcastingClass:'',spellcastingAbility:'',
        spellSaveDC:0,spellAttackBonus:0,
        concentratingOn:'', dmInspiration:false,
        spellSlots:{1:{max:0,used:0},2:{max:0,used:0},3:{max:0,used:0},4:{max:0,used:0},
                    5:{max:0,used:0},6:{max:0,used:0},7:{max:0,used:0},8:{max:0,used:0},9:{max:0,used:0}},
        pactSlots:{max:0,used:0,level:1},
        selectedSpells:[],selectedFeats:[],equipmentItems:[],
        additionalFeaturesTraits:'',
        createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),
    };
}

// ==================== UTILITY ====================
function calcMod(score) { return Math.floor((score - 10) / 2); }
function modStr(mod) { return mod >= 0 ? '+' + mod : '' + mod; }
function $(sel) { return document.querySelector(sel); }
function $$(sel) { return document.querySelectorAll(sel); }
function esc(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

const SKILL_ABILITY = {
    acrobatics:'dexterity',animalHandling:'wisdom',arcana:'intelligence',athletics:'strength',
    deception:'charisma',history:'intelligence',insight:'wisdom',intimidation:'charisma',
    investigation:'intelligence',medicine:'wisdom',nature:'intelligence',perception:'wisdom',
    performance:'charisma',persuasion:'charisma',religion:'intelligence',
    sleightOfHand:'dexterity',stealth:'dexterity',survival:'wisdom',
};
const SKILL_LABELS = {
    acrobatics:'Acrobatics',animalHandling:'Animal Handling',arcana:'Arcana',athletics:'Athletics',
    deception:'Deception',history:'History',insight:'Insight',intimidation:'Intimidation',
    investigation:'Investigation',medicine:'Medicine',nature:'Nature',perception:'Perception',
    performance:'Performance',persuasion:'Persuasion',religion:'Religion',
    sleightOfHand:'Sleight of Hand',stealth:'Stealth',survival:'Survival',
};
const AB_SHORT = {strength:'STR',dexterity:'DEX',constitution:'CON',intelligence:'INT',wisdom:'WIS',charisma:'CHA'};
const AB_ICONS = {strength:'💪',dexterity:'🏃',constitution:'🛡️',intelligence:'🧠',wisdom:'👁️',charisma:'✨'};
const COIN_ICONS = {cp:'🟤',sp:'⚪',ep:'🔵',gp:'🟡',pp:'💎'};
const SKILL_ICONS = {athletics:'🏋️',acrobatics:'🤸',sleightOfHand:'🤏',stealth:'🥷',arcana:'📖',history:'📜',investigation:'🔍',nature:'🌿',religion:'⛪',animalHandling:'🐾',insight:'💡',medicine:'⚕️',perception:'👀',survival:'🏕️',deception:'🎭',intimidation:'😤',performance:'🎵',persuasion:'🗣️'};
const AB_FROM_SHORT = {str:'strength',dex:'dexterity',con:'constitution',int:'intelligence',wis:'wisdom',cha:'charisma'};

// ==================== RULES: Derived Stats (2014 PHB) ====================
// Spell save DC = 8 + proficiency + spellcasting modifier
function calcSpellSaveDC(char) {
    const ab = CLASS_SPELL_ABILITY[char.charClass] || char.spellcastingAbility?.toLowerCase();
    if (!ab) return 0;
    const full = AB_FROM_SHORT[ab] || ab;
    return 8 + char.profBonus + calcMod(char[full] || 10);
}
// Spell attack bonus = proficiency + spellcasting modifier
function calcSpellAttackBonus(char) {
    const ab = CLASS_SPELL_ABILITY[char.charClass] || char.spellcastingAbility?.toLowerCase();
    if (!ab) return 0;
    const full = AB_FROM_SHORT[ab] || ab;
    return char.profBonus + calcMod(char[full] || 10);
}
// Passive Perception = 10 + Perception modifier (includes proficiency if proficient)
function calcPassivePerception(char) {
    const perceptionProf = char.skills.perception || 0;
    return 10 + calcMod(char.wisdom) + (char.profBonus * perceptionProf);
}
// Initiative = DEX modifier
function calcInitiative(char) { return calcMod(char.dexterity); }
// AC calculation: base 10 + DEX mod (unarmored)
function calcBaseAC(char) {
    let ac = 10 + calcMod(char.dexterity);
    // Check equipped armor
    const armor = (char.equipmentItems||[]).find(i => i.category === 'Armor' && i.armorType);
    if (armor) {
        if (armor.armorType === 'light') ac = (armor.ac||0) + calcMod(char.dexterity);
        else if (armor.armorType === 'medium') ac = (armor.ac||0) + Math.min(2, calcMod(char.dexterity));
        else if (armor.armorType === 'heavy') ac = armor.ac||0;
    }
    // Unarmored Defense: Barbarian = 10+DEX+CON, Monk = 10+DEX+WIS
    if (!armor) {
        if (char.charClass === 'Barbarian') ac = 10 + calcMod(char.dexterity) + calcMod(char.constitution);
        if (char.charClass === 'Monk') ac = 10 + calcMod(char.dexterity) + calcMod(char.wisdom);
    }
    // Shield
    const shield = (char.equipmentItems||[]).find(i => i.name && i.name.toLowerCase().includes('shield'));
    if (shield) ac += 2;
    return ac;
}

function calcAttackBonus(char, item) {
    if (!item) return 0;
    const props = (item.properties || '').toLowerCase();
    const isFinesse = props.includes('finesse');
    const isRanged = (item.weaponCategory||'').toLowerCase().includes('ranged') || props.includes('ammunition') || props.includes('thrown');
    let abilityMod;
    if (isFinesse) abilityMod = Math.max(calcMod(char.strength), calcMod(char.dexterity));
    else if (isRanged) abilityMod = calcMod(char.dexterity);
    else abilityMod = calcMod(char.strength);
    return char.profBonus + abilityMod;
}

function getMaxPreparedSpells(char) {
    const cls = char.charClass;
    const level = char.level || 1;
    const classData = CLASSES.find(c => c.name === cls);
    if (!classData) return Infinity;
    const ab = CLASS_SPELL_ABILITY[cls];
    if (!ab) return Infinity;
    const full = AB_FROM_SHORT[ab] || ab;
    const abMod = calcMod(char[full] || 10);
    if (PREPARED_CASTERS.includes(cls)) return Math.max(1, abMod + level);
    if (classData.spellsKnownProgression && classData.spellsKnownProgression.length >= level && classData.spellsKnownProgression[level-1] > 0)
        return classData.spellsKnownProgression[level - 1];
    return Infinity;
}

// ==================== NAVIGATION ====================
let currentChar = null;
let currentPage = 'home';
let currentTab = 'main';

// Zoom controls
let zoomLevel = 100;
function zoomIn() { zoomLevel = Math.min(150, zoomLevel + 10); applyZoom(); }
function zoomOut() { zoomLevel = Math.max(50, zoomLevel - 10); applyZoom(); }
function applyZoom() { const s=document.querySelector('.sheet'); if(s){s.style.transform='scale('+(zoomLevel/100)+')';s.style.transformOrigin='top center';} const el=document.getElementById('zoom-level'); if(el) el.textContent=zoomLevel+'%'; }

function navigate(page, charId) {
    currentPage = page;
    currentTab = 'main';
    if (charId) currentChar = getCharacter(charId);
    render();
    const bar = $('#sheet-actions-bar');
    if (bar) bar.style.display = page === 'sheet' ? 'flex' : 'none';
    const lvlBar = $('#sheet-level-bar');
    if (lvlBar) lvlBar.style.display = page === 'sheet' ? 'flex' : 'none';
    if (page === 'sheet' && currentChar) {
        const lvlEl = $('#topbar-level');
        if (lvlEl) {
            if (currentChar.classLevels && Object.keys(currentChar.classLevels).length > 1) {
                lvlEl.textContent = 'Lvl ' + currentChar.level + ' (' + getMulticlassDisplay(currentChar) + ')';
            } else {
                lvlEl.textContent = 'Lvl ' + currentChar.level;
            }
        }
    }
}

// ==================== MODAL ====================
let modalCallback = null;
let modalItems = [];
let modalFiltered = [];

function openModal(title, items, callback) {
    modalItems = items; modalFiltered = items; modalCallback = callback;
    $('#modal-title').textContent = title;
    $('#modal-search').value = '';
    renderModalItems(items);
    $('#modal-overlay').style.display = 'flex';
    setTimeout(() => $('#modal-search').focus(), 50);
}
function closeModal() { $('#modal-overlay').style.display = 'none'; modalCallback = null; const s=$('#modal-search'); if(s)s.style.display=''; }
function filterModal(query) {
    const q = query.toLowerCase();
    modalFiltered = modalItems.filter(i => i.name.toLowerCase().includes(q) || (i.sub||'').toLowerCase().includes(q) || (i.desc||'').toLowerCase().includes(q));
    renderModalItems(modalFiltered);
}
function renderModalItems(items) {
    const body = $('#modal-body');
    if (!items.length) {
        body.innerHTML = '<div class="modal-empty">No results found</div>' +
            '<div style="text-align:center;padding:8px"><button class="btn btn-primary" onclick="closeModal();addCustomEquipment()">+ Add Custom Item</button></div>';
        return;
    }
    body.innerHTML = items.map((item, i) => `
        <div class="modal-item" onclick="selectModalItem(${i})">
            <div class="mi-name">${item.name}</div>
            ${item.sub ? `<div class="mi-sub">${item.sub}</div>` : ''}
            ${item.badges ? `<div class="mi-badges">${item.badges.map(b => `<span class="badge badge-${b.type}">${b.label}</span>`).join('')}</div>` : ''}
            ${item.desc ? `<div class="mi-desc">${item.desc.substring(0,150)}${item.desc.length>150?'...':''}</div>` : ''}
        </div>
    `).join('');
}
function selectModalItem(idx) { const item = modalFiltered[idx]; if (modalCallback) modalCallback(item); closeModal(); }

// ==================== SPELL DETAIL POPUP ====================
function openSpellDetail(spellName) {
    const spell = SPELLS.find(s => s.name === spellName);
    if (!spell) return;
    const access = SPELL_ACCESS[spell.name.toLowerCase()] || {};
    const classes = (access.classes || []).join(', ') || 'None listed';
    const overlay = $('#spell-detail-overlay');
    const title = $('#spell-detail-title');
    const body = $('#spell-detail-body');
    title.textContent = spell.name;
    body.innerHTML = `
        <div class="spell-detail-grid">
            <div class="sd-row"><strong>Level:</strong> ${spell.level === 0 ? 'Cantrip' : spell.level}</div>
            <div class="sd-row"><strong>School:</strong> ${esc(spell.school)}</div>
            <div class="sd-row"><strong>Casting Time:</strong> ${esc(spell.castingTime)}</div>
            <div class="sd-row"><strong>Range:</strong> ${esc(spell.range)}</div>
            <div class="sd-row"><strong>Components:</strong> ${esc(spell.components)}</div>
            <div class="sd-row"><strong>Duration:</strong> ${esc(spell.duration)}</div>
            ${spell.concentration ? '<div class="sd-row"><span class="badge badge-info">Concentration</span></div>' : ''}
            ${spell.ritual ? '<div class="sd-row"><span class="badge badge-info">Ritual</span></div>' : ''}
            ${spell.castingTime && (spell.castingTime.toLowerCase().startsWith('1 bonus') || spell.castingTime.toLowerCase() === 'bonus action') ? '<div class="sd-row"><span class="badge badge-info">Bonus Action</span></div>' : ''}
            ${spell.castingTime && spell.castingTime.toLowerCase().startsWith('1 reaction') ? '<div class="sd-row"><span class="badge badge-info">Reaction</span></div>' : ''}
        </div>
        <div class="sd-description">
            <strong>Description:</strong>
            <p>${esc(spell.description || 'No description available.')}</p>
        </div>
        ${spell.higherLevel ? `<div class="sd-higher"><strong>At Higher Levels:</strong><p>${esc(spell.higherLevel)}</p></div>` : ''}
        <div class="sd-classes"><strong>Classes:</strong> ${esc(classes)}</div>
        <div class="sd-source"><strong>Source:</strong> ${esc(spell.source || 'Unknown')}</div>
    `;
    overlay.style.display = 'flex';
}
function closeSpellDetail() { $('#spell-detail-overlay').style.display = 'none'; }

// ==================== PICKERS ====================
function openRacePicker(cb) {
    const items = RACES.map(r => ({
        name: r.name, raw: r,
        sub: `Source: ${r.source}`,
        badges: [
            ...(r.darkvision ? [{type:'racial',label:'Darkvision'}] : []),
            ...(r.ability&&r.ability.length ? [{type:'racial',label:Object.entries(r.ability[0]).map(([k,v])=>`${k.toUpperCase()} +${v}`).join(', ')}] : []),
        ],
    }));
    openModal('Select Race', items, cb);
}
function openClassPicker(cb) {
    const items = CLASSES.map(c => ({
        name: c.name, raw: c,
        sub: `Hit Die: d${c.hd.faces} | Saves: ${c.proficiency.map(p=>p.toUpperCase()).join(', ')}`,
        badges: [
            ...(c.spellcastingAbility ? [{type:'class',label:`Spellcaster (${c.spellcastingAbility.toUpperCase()})`}] : []),
            {type:'info',label:`${c.subclasses.length} subclasses`},
        ],
    }));
    openModal('Select Class', items, cb);
}
function openSubclassPicker(className, cb) {
    const cls = CLASSES.find(c => c.name === className);
    if (!cls) return;
    openModal(`${className} Subclasses`, cls.subclasses.map(sc => ({name:sc.name,raw:sc,sub:`Source: ${sc.source}`})), cb);
}
function openBackgroundPicker(cb) {
    openModal('Select Background', BACKGROUNDS.map(b => ({name:b.name,raw:b,sub:`Source: ${b.source}`,desc:b.entries||''})), cb);
}
function openEquipmentPicker(cb) {
    const items = (typeof EQUIPMENT !== 'undefined' ? EQUIPMENT : []).map(item => {
        const d = [];
        if (item.damage) d.push(item.damage);
        if (item.ac) d.push('AC '+item.ac+(item.armorType?' ('+item.armorType+')':''));
        if (item.weight) d.push(item.weight+' lb');
        if (item.value) d.push(item.value);
        if (item.properties) d.push(item.properties);
        return {name:item.name,raw:item,sub:d.join(' · '),
            badges:[{type:item.category==='Weapon'?'class':item.category==='Armor'?'racial':'info',label:item.category}]};
    });
    openModal('Add Equipment', items, cb);
}
function openFeatPicker(cb) {
    openModal('Select Feat', FEATS.map(f => ({name:f.name,raw:f,sub:`Source: ${f.source}`,desc:f.entries||'',
        badges:f.ability&&f.ability.length?[{type:'feat',label:'ASI: '+Object.keys(f.ability[0]).map(k=>k.toUpperCase()).join('/')}]:[]})), cb);
}
function openSpellPicker(level, charClass, subclass, race, cb) {
    const spells = SPELLS.filter(s => s.level === level);
    const items = [];
    for (const s of spells) {
        const access = SPELL_ACCESS[s.name.toLowerCase()] || {};
        const sources = [];
        if (charClass && (access.classes||[]).includes(charClass)) sources.push({type:'class',label:charClass});
        if (subclass && charClass) {
            for (const sc of (access.subclasses||[])) {
                if (sc.class === charClass && sc.subclass === subclass) { sources.push({type:'subclass',label:subclass}); break; }
            }
        }
        if (race) {
            for (const r of (access.races||[])) {
                if (race.toLowerCase().includes(r.toLowerCase())) { sources.push({type:'race',label:race}); break; }
            }
        }
        if (sources.length > 0 || !charClass) {
            items.push({name:s.name,raw:{...s,sources},
                sub:`${s.school} · ${s.castingTime} · ${s.range} · ${s.duration}`,
                desc:s.description||'',
                badges:[
                    ...(s.concentration?[{type:'info',label:'Concentration'}]:[]),
                    ...(s.ritual?[{type:'info',label:'Ritual'}]:[]),
                    ...sources,
                ],
            });
        }
    }
    openModal(level===0?'Select Cantrip':`Select Level ${level} Spell`, items, cb);
}


// ==================== RENDER ====================
function render() {
    const app = $('#app');
    switch(currentPage) {
        case 'home': app.innerHTML = renderHome(); break;
        case 'create': app.innerHTML = renderCreate(); break;
        case 'sheet': app.innerHTML = renderSheet(); break;
    }
    if (currentPage === 'sheet' && currentChar) {
        const lvlEl = $('#topbar-level');
        if (lvlEl) lvlEl.textContent = 'Lvl ' + currentChar.level;
    }
}

function renderHome() {
    const chars = loadCharacters();
    return `
    <div class="home">
        <div class="welcome">
            <h1>Mokx's Character Management Tool</h1>
            <p class="subtitle">D&D 5th Edition (2014) Character Creation & Management</p>
        </div>
        <div class="home-actions">
            <div class="action-card" onclick="navigate('create')">
                <div class="action-icon">📝</div>
                <h2>Create New Character</h2>
                <p>Start with a blank 5e character sheet</p>
            </div>
            <label class="action-card">
                <div class="action-icon">📄</div>
                <h2>Upload Existing</h2>
                <p>Import from PDF or JSON</p>
                <input type="file" accept=".pdf,.json" onchange="handleUpload(this)" hidden>
            </label>
        </div>
        ${chars.length ? `
            <h2 class="section-title">Your Characters</h2>
            <div class="char-grid">
                ${chars.map(c => `
                    <div class="char-card" onclick="navigate('sheet','${c.id}')">
                        <button class="char-delete" onclick="event.stopPropagation();if(confirm('Delete ${esc(c.name)}?')){deleteCharacter('${c.id}');render()}" title="Delete">×</button>
                        <div class="char-avatar">${(c.name||'?')[0]}</div>
                        <div class="char-info">
                            <h3>${esc(c.name)}</h3>
                            <div class="char-detail">${esc(c.race)} ${c.classLevels && Object.keys(c.classLevels).length > 1 ? esc(getMulticlassDisplay(c)) : esc(c.charClass) + (c.subclass?' ('+esc(c.subclass)+')':'')} ${c.level?'· Lvl '+c.level:''}</div>
                            <div class="char-stats">
                                <span class="hp-badge">HP ${c.hpCurrent}/${c.hpMax}</span>
                                <span class="ac-badge">AC ${c.ac}</span>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        ` : `
            <div class="empty-state">
                <div class="empty-icon">📋</div>
                <h2>No Characters Yet</h2>
                <p>Create your first character or upload an existing one.</p>
            </div>
        `}
    </div>`;
}

// ==================== CREATE PAGE ====================
let createRace='',createClass='',createSubclass='',createBg='';
let createClassData=null;
let createSkillPicks={};
let createSkillMax=0;

function renderCreate() {
    const classSkills = createClassData?.startingProficiencies?.skills?.[0]?.choose;
    const skillFrom = classSkills?.from || [];
    const skillCount = classSkills?.count || 0;
    createSkillMax = skillCount;

    return `
    <div class="create-page">
        <h1 class="page-title">Create New Character</h1>
        <div class="create-form">
            <div class="cf-section">
                <div class="cf-field full"><label>Character Name</label>
                    <input type="text" id="c-name" placeholder="Enter character name" autofocus>
                </div>
            </div>
            <div class="cf-section">
                <div class="cf-field"><label>Race</label>
                    <button class="picker-btn" id="c-race-btn" onclick="pickRace()">Select Race... ▼</button>
                </div>
                <div class="cf-field"><label>Class</label>
                    <button class="picker-btn" id="c-class-btn" onclick="pickClass()">Select Class... ▼</button>
                </div>
                <div class="cf-field sm"><label>Level</label>
                    <input type="number" id="c-level" value="1" min="1" max="20">
                </div>
            </div>
            <div class="cf-section">
                <div class="cf-field"><label>Subclass</label>
                    <button class="picker-btn" id="c-subclass-btn" onclick="pickSubclass()" disabled>Select class first... ▼</button>
                </div>
                <div class="cf-field"><label>Background</label>
                    <button class="picker-btn" id="c-bg-btn" onclick="pickBackground()">Select Background... ▼</button>
                </div>
                <div class="cf-field"><label>Alignment</label>
                    <select id="c-alignment"><option value="">Select...</option>
                        ${['Lawful Good','Neutral Good','Chaotic Good','Lawful Neutral','True Neutral','Chaotic Neutral','Lawful Evil','Neutral Evil','Chaotic Evil']
                          .map(a=>`<option>${a}</option>`).join('')}
                    </select>
                </div>
            </div>

            ${skillFrom.length ? `
            <h3 class="cf-subtitle">Skill Proficiencies (pick ${skillCount})</h3>
            <div class="skill-count" id="skill-count-display">0 / ${skillCount} selected</div>
            <div class="skill-select-grid" id="skill-select-grid">
                ${skillFrom.map(sk => {
                    const key = sk.replace(/\s+/g,'');
                    const camel = key.charAt(0).toLowerCase() + key.slice(1);
                    return `<label class="skill-select-item">
                        <input type="checkbox" data-skill="${camel}" onchange="updateCreateSkills()">
                        ${SKILL_LABELS[camel]||sk}
                    </label>`;
                }).join('')}
            </div>
            ` : (createClass ? '<p style="font-size:.8rem;color:#666;margin:8px 0">Select a class to see skill choices.</p>' : '')}

            <h3 class="cf-subtitle">Ability Scores</h3>
            <div class="ab-method-bar">
                <button class="ab-method active" onclick="setAbMethod('manual',this)">Manual</button>
                <button class="ab-method" onclick="setAbMethod('standard',this)">Standard Array</button>
                <button class="ab-method" onclick="setAbMethod('pointbuy',this)">Point Buy</button>
                <button class="ab-method" onclick="setAbMethod('roll',this)">Roll 4d6</button>
            </div>
            <div id="ab-method-info" class="ab-method-info"></div>
            <div id="pointbuy-tracker" class="pb-tracker" style="display:none">Points remaining: <strong id="pb-points">27</strong> / 27</div>
            <div class="cf-abilities">
                ${['STR','DEX','CON','INT','WIS','CHA'].map(ab=>`
                    <div class="cf-ab"><label>${ab}</label>
                        <input type="number" id="c-${ab.toLowerCase()}" value="10" min="1" max="30" oninput="updateCreateMod(this);updatePointBuy()">
                        <div class="cf-ab-mod" id="c-${ab.toLowerCase()}-mod">+0</div>
                    </div>
                `).join('')}
            </div>
            <h3 class="cf-subtitle">Combat</h3>
            <div class="cf-section">
                <div class="cf-field sm"><label>AC</label><input type="number" id="c-ac" value="10"></div>
                <div class="cf-field sm"><label>HP</label><input type="number" id="c-hp" value="10"></div>
                <div class="cf-field sm"><label>Speed</label><input type="number" id="c-speed" value="30"></div>
                <div class="cf-field sm"><label>Hit Dice</label><input type="text" id="c-hd" value="1d10" readonly></div>
            </div>
            <div class="cf-actions">
                <button class="btn btn-secondary" onclick="navigate('home')">Cancel</button>
                <button class="btn btn-primary" onclick="createCharacter()">Create Character</button>
            </div>
        </div>
    </div>`;
}

function updateCreateSkills() {
    const checks = $$('#skill-select-grid input[type=checkbox]');
    const picked = [];
    checks.forEach(cb => { if (cb.checked) picked.push(cb.dataset.skill); });
    createSkillPicks = {};
    picked.forEach(s => createSkillPicks[s] = 1);
    const countEl = $('#skill-count-display');
    if (countEl) countEl.textContent = `${picked.length} / ${createSkillMax} selected`;
    checks.forEach(cb => {
        if (!cb.checked && picked.length >= createSkillMax) cb.disabled = true;
        else cb.disabled = false;
    });
}

function pickRace() {
    openRacePicker(item => {
        createRace = item.name;
        $('#c-race-btn').textContent = item.name + ' ▼';
        $('#c-race-btn').classList.add('selected');
        if (item.raw.speed) {
            const spd = typeof item.raw.speed === 'object' ? (item.raw.speed.walk||30) : item.raw.speed;
            const el = $('#c-speed'); if (el) el.value = spd;
        }
    });
}
function pickClass() {
    openClassPicker(item => {
        createClass = item.name;
        createClassData = item.raw;
        createSkillPicks = {};
        $('#c-class-btn').textContent = item.name + ' ▼';
        $('#c-class-btn').classList.add('selected');
        $('#c-hd').value = '1d' + item.raw.hd.faces;
        const scBtn = $('#c-subclass-btn');
        scBtn.disabled = false; scBtn.textContent = 'Select Subclass... ▼';
        createSubclass = '';
        const old = $('#c-name')?.value;
        render();
        if (old) { const n = $('#c-name'); if (n) n.value = old; }
        setTimeout(() => {
            if (createRace) { const b=$('#c-race-btn'); if(b){b.textContent=createRace+' ▼';b.classList.add('selected');}}
            if (createClass) { const b=$('#c-class-btn'); if(b){b.textContent=createClass+' ▼';b.classList.add('selected');}}
            if (createBg) { const b=$('#c-bg-btn'); if(b){b.textContent=createBg+' ▼';b.classList.add('selected');}}
            const scBtn2=$('#c-subclass-btn'); if(scBtn2){scBtn2.disabled=false; if(createSubclass){scBtn2.textContent=createSubclass+' ▼';scBtn2.classList.add('selected');}else{scBtn2.textContent='Select Subclass... ▼';}}
            $('#c-hd').value = '1d'+createClassData.hd.faces;
        }, 10);
    });
}
function pickSubclass() {
    if (!createClass) return;
    openSubclassPicker(createClass, item => {
        createSubclass = item.name;
        $('#c-subclass-btn').textContent = item.name + ' ▼';
        $('#c-subclass-btn').classList.add('selected');
    });
}
function pickBackground() {
    openBackgroundPicker(item => {
        createBg = item.name;
        $('#c-bg-btn').textContent = item.name + ' ▼';
        $('#c-bg-btn').classList.add('selected');
    });
}

let currentAbMethod = 'manual';
function updateCreateMod(input) {
    const val = parseInt(input.value) || 10;
    const modEl = $('#' + input.id + '-mod');
    if (modEl) modEl.textContent = modStr(calcMod(val));
}
function setAbMethod(method, btn) {
    currentAbMethod = method;
    $$('.ab-method').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    const info=$('#ab-method-info'); const pbTracker=$('#pointbuy-tracker');
    const abs=['str','dex','con','int','wis','cha'];
    switch(method) {
        case 'manual':
            info.textContent='Enter scores manually.';
            if(pbTracker)pbTracker.style.display='none';
            abs.forEach(ab=>{const el=$(`#c-${ab}`);if(el){el.readOnly=false;el.min=1;el.max=30;}});
            break;
        case 'standard':
            info.textContent='Assign: 15, 14, 13, 12, 10, 8';
            if(pbTracker)pbTracker.style.display='none';
            [15,14,13,12,10,8].forEach((v,i)=>{const el=$(`#c-${abs[i]}`);if(el){el.value=v;el.readOnly=false;updateCreateMod(el);}});
            break;
        case 'pointbuy':
            info.innerHTML='Scores 8-15. Cost: 8=0, 9=1, 10=2, 11=3, 12=4, 13=5, 14=7, 15=9';
            if(pbTracker)pbTracker.style.display='block';
            abs.forEach(ab=>{const el=$(`#c-${ab}`);if(el){el.value=8;el.readOnly=false;el.min=8;el.max=15;updateCreateMod(el);}});
            updatePointBuy();
            break;
        case 'roll':
            if(pbTracker)pbTracker.style.display='none';
            abs.forEach(ab=>{
                const rolls=[1,2,3,4].map(()=>Math.floor(Math.random()*6)+1);
                rolls.sort((a,b)=>b-a);
                const el=$(`#c-${ab}`);if(el){el.value=rolls[0]+rolls[1]+rolls[2];el.readOnly=false;updateCreateMod(el);}
            });
            info.textContent='Rolled! Rearrange as desired.';
            break;
    }
}
const POINT_BUY_COST={8:0,9:1,10:2,11:3,12:4,13:5,14:7,15:9};
function updatePointBuy() {
    if(currentAbMethod!=='pointbuy')return;
    let spent=0;
    ['str','dex','con','int','wis','cha'].forEach(ab=>{
        const val=parseInt($(`#c-${ab}`)?.value)||8;
        spent+=POINT_BUY_COST[Math.max(8,Math.min(15,val))]||0;
    });
    const el=$('#pb-points');
    if(el){el.textContent=27-spent;el.style.color=(27-spent)<0?'#8b1a1a':(27-spent)===0?'#2a7a2a':'#1a1a1a';}
}

function createCharacter() {
    const name = ($('#c-name')||{}).value || '';
    if (!name.trim()) { alert('Please enter a character name.'); return; }
    const char = defaultCharacter();
    char.name = name.trim();
    char.race = createRace;
    char.charClass = createClass;
    char.subclass = createSubclass;
    char.background = createBg;
    char.level = parseInt($('#c-level').value) || 1;
    char.alignment = $('#c-alignment').value;
    char.strength = parseInt($('#c-str').value) || 10;
    char.dexterity = parseInt($('#c-dex').value) || 10;
    char.constitution = parseInt($('#c-con').value) || 10;
    char.intelligence = parseInt($('#c-int').value) || 10;
    char.wisdom = parseInt($('#c-wis').value) || 10;
    char.charisma = parseInt($('#c-cha').value) || 10;
    char.ac = parseInt($('#c-ac').value) || 10;
    char.hpMax = parseInt($('#c-hp').value) || 10;
    char.hpCurrent = char.hpMax;
    char.speed = parseInt($('#c-speed').value) || 30;
    char.hitDice = $('#c-hd').value || '1d10';
    char.hitDiceRemaining = char.level;
    char.profBonus = profBonusByLevel(char.level);
    char.initiative = calcInitiative(char);
    char.passivePerception = calcPassivePerception(char);

    // Skill proficiencies
    for (const [sk, v] of Object.entries(createSkillPicks)) {
        char.skills[sk] = v;
    }
    char.passivePerception = calcPassivePerception(char);

    // Save proficiencies from class
    if (createClassData?.proficiency) {
        for (const p of createClassData.proficiency) char.saveProficiency[p] = true;
    }

    // Spellcasting setup
    if (createClassData?.spellcastingAbility) {
        char.spellcastingClass = createClass;
        char.spellcastingAbility = createClassData.spellcastingAbility.toUpperCase();
        char.spellSaveDC = calcSpellSaveDC(char);
        char.spellAttackBonus = calcSpellAttackBonus(char);
        applySpellSlots(char);
        autoLoadStartingSpells(char);
    }

    if (createClass === 'Warlock') {
        const ps = PACT_SLOTS[char.level];
        if (ps) { char.pactSlots = {max:ps[0], used:0, level:ps[1]}; }
    }

    saveCharacter(char);
    currentChar = char;
    createRace=''; createClass=''; createSubclass=''; createBg=''; createClassData=null; createSkillPicks={};
    navigate('sheet', char.id);
}

function applySpellSlots(char) {
    const slots = getSpellSlotsForClass(char.charClass, char.level);
    if (slots) {
        for (let i = 0; i < 9; i++) {
            char.spellSlots[i+1].max = slots[i];
            char.spellSlots[i+1].used = 0;
        }
    }
}

function autoLoadStartingSpells(char) {
    const cls = char.charClass;
    const classData = CLASSES.find(c => c.name === cls);
    if (!classData || !classData.spellcastingAbility) return;
    const classSpells = SPELLS.filter(s => {
        const access = SPELL_ACCESS[s.name.toLowerCase()];
        if (!access) return false;
        return (access.classes || []).includes(cls);
    });
    const numCantrips = classData.cantripProgression?.[char.level - 1] || 0;
    const cantrips = classSpells.filter(s => s.level === 0);
    for (let i = 0; i < Math.min(numCantrips, cantrips.length); i++) {
        char.selectedSpells.push({
            name: cantrips[i].name, level: 0, school: cantrips[i].school,
            ritual: cantrips[i].ritual, concentration: cantrips[i].concentration,
            sources: [{type:'class', label:cls}],
        });
    }
    if (KNOWN_CASTERS.includes(cls)) {
        const numKnown = classData.spellsKnownProgression?.[char.level - 1] || 0;
        const lvl1 = classSpells.filter(s => s.level === 1);
        for (let i = 0; i < Math.min(numKnown, lvl1.length); i++) {
            char.selectedSpells.push({
                name: lvl1[i].name, level: 1, school: lvl1[i].school,
                ritual: lvl1[i].ritual, concentration: lvl1[i].concentration,
                sources: [{type:'class', label:cls}],
            });
        }
    }
    if (PREPARED_CASTERS.includes(cls)) {
        const maxPrep = getMaxPreparedSpells(char);
        const lvl1 = classSpells.filter(s => s.level === 1);
        for (let i = 0; i < Math.min(maxPrep, lvl1.length, 4); i++) {
            char.selectedSpells.push({
                name: lvl1[i].name, level: 1, school: lvl1[i].school,
                ritual: lvl1[i].ritual, concentration: lvl1[i].concentration,
                sources: [{type:'class', label:cls}], prepared: true,
            });
        }
    }
}

// ==================== FILE UPLOAD ====================
function handleUpload(input) {
    const file = input.files[0]; if (!file) return;
    const fname = file.name.toLowerCase();
    if (fname.endsWith('.json')) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = JSON.parse(e.target.result);
                const char = defaultCharacter(); Object.assign(char, data); char.id = newCharId();
                saveCharacter(char); navigate('sheet', char.id);
            } catch(err) { alert('Could not parse JSON: '+err.message); }
        };
        reader.readAsText(file);
    } else if (fname.endsWith('.pdf')) {
        parsePDF(file);
    }
    input.value = '';
}

// ==================== PDF PARSING (FIXED v7) ====================
let pdfjsLoaded = false;
function loadPdfJs() {
    return new Promise((resolve, reject) => {
        if (pdfjsLoaded) { resolve(); return; }
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
        script.onload = () => {
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
            pdfjsLoaded = true; resolve();
        };
        script.onerror = () => reject(new Error('Failed to load PDF.js'));
        document.head.appendChild(script);
    });
}

async function parsePDF(file) {
    try {
        await loadPdfJs();
        const ab = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({data:ab}).promise;
        const formData = {};
        let fullText = '';
        for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const annots = await page.getAnnotations();
            for (const a of annots) {
                if (a.fieldName && a.fieldValue !== undefined && a.fieldValue !== null) {
                    formData[a.fieldName] = String(a.fieldValue).trim();
                }
            }
            const tc = await page.getTextContent();
            fullText += tc.items.map(item=>item.str).join(' ') + '\n';
        }
        const char = defaultCharacter();
        console.log('PDF form fields:', JSON.stringify(formData, null, 2));
        if (Object.keys(formData).length > 0) {
            mapFormFields(formData, char);
        }
        mapTextContent(fullText, char);
        parseFilename(file.name, char);
        matchToGameData(char);
        if (!char.name || char.name === 'New Character') char.name = file.name.replace(/\.pdf$/i,'');

        // Recalc derived stats per 2014 rules
        char.profBonus = profBonusByLevel(char.level);
        char.spellSaveDC = calcSpellSaveDC(char) || char.spellSaveDC;
        char.spellAttackBonus = calcSpellAttackBonus(char) || char.spellAttackBonus;
        char.passivePerception = calcPassivePerception(char);
        char.initiative = calcInitiative(char);

        (char.equipmentItems||[]).forEach(item => {
            if (item.category === 'Weapon') item.attackBonus = calcAttackBonus(char, item);
        });

        saveCharacter(char);
        navigate('sheet', char.id);
        showImportSummary(char);
    } catch(err) {
        console.error('PDF parse error:', err);
        const char = defaultCharacter();
        char.name = file.name.replace(/\.pdf$/i,'');
        saveCharacter(char); navigate('sheet', char.id);
        alert('Could not fully parse PDF ('+err.message+'). Please fill in details manually.');
    }
}

function showImportSummary(char) {
    const checks = [
        ['Name', char.name && char.name !== 'New Character'],
        ['Race', !!char.race], ['Class', !!char.charClass], ['Subclass', !!char.subclass],
        ['Level', char.level > 1], ['Background', !!char.background],
        ['Ability Scores', [char.strength,char.dexterity,char.constitution,char.intelligence,char.wisdom,char.charisma].some(s=>s!==10)],
        ['HP', char.hpMax > 10], ['AC', char.ac !== 10],
        ['Skills', Object.values(char.skills).some(v=>v>0)],
        ['Spells', char.selectedSpells.length > 0],
        ['Equipment', (char.equipmentItems||[]).length > 0],
        ['Proficiencies', !!char.proficienciesLanguages],
    ];
    const found = checks.filter(([,ok])=>ok).map(([l])=>'✅ '+l);
    const missing = checks.filter(([,ok])=>!ok).map(([l])=>'❌ '+l);
    alert(`Imported: ${char.name}\n\nFound (${found.length}):\n${found.join('\n')}\n\nNot found (${missing.length}):\n${missing.join('\n')}`);
}

function mapFormFields(fields, char) {
    const norm = s => s.toLowerCase().replace(/[\s_.\-()]+/g,'').replace(/[^a-z0-9]/g,'');
    const nFields = {};
    for (const [k,v] of Object.entries(fields)) {
        const val = String(v||'').trim();
        if (val) nFields[norm(k)] = val;
    }
    // Also keep original keys for direct matching
    const origFields = {};
    for (const [k,v] of Object.entries(fields)) {
        origFields[k] = String(v||'').trim();
    }
    function find(...patterns) { for(const p of patterns){const key=norm(p);if(nFields[key]!==undefined)return nFields[key];}return ''; }
    function findInt(...patterns) { const v=find(...patterns);if(!v)return 0;const n=parseInt(v.replace(/[^\d\-]/g,''));return isNaN(n)?0:n; }

    // Core
    char.name = find('charactername','charname','pcname','name','CharacterName') || char.name;
    char.playerName = find('playername','player','PlayerName') || char.playerName;
    char.race = find('race','raceethnicity','Race') || char.race;
    char.background = find('background','Background') || char.background;
    char.alignment = find('alignment','Alignment') || char.alignment;

    const classLvl = find('classlevel','classandlevel','class','ClassLevel');
    if (classLvl) {
        // Handle patterns like "Bard [College of Tragedy] (3)" or "Bard 3" or "Fighter/Wizard 5/3"
        const bracketMatch = classLvl.match(/^([A-Za-z\s]+?)\s*\[([^\]]+)\]\s*\((\d+)\)/);
        if (bracketMatch) {
            char.charClass = bracketMatch[1].trim();
            char.subclass = bracketMatch[2].trim();
            char.level = parseInt(bracketMatch[3]);
        } else {
            const match = classLvl.match(/^([A-Za-z\s]+?)\s*(\d+)/);
            if (match) { char.charClass = match[1].trim(); char.level = parseInt(match[2]); }
            else char.charClass = classLvl;
        }
    }
    const rawSub = find('subclass','archetype','primalpath','bardcollege','divinedomain','druidcircle',
        'martialarchetype','monastictradition','sacredoath','rangerarchetype','roguisharchetype',
        'sorcerousorigin','otherworldlypatron','arcanetradition');
    if (rawSub && !/^\d+$/.test(rawSub)) char.subclass = rawSub;
    char.xp = findInt('experiencepoints','xp','exp') || char.xp;

    // ABILITY SCORES - FIXED v7b: Many PDF generators (including popular 5e sheets) store
    // the SCORE in the "-mod" field and the MODIFIER in the base field (e.g. str-mod=9, str=-1).
    // We detect this by checking: if the "-mod" field has a value 3-30 AND the base field looks
    // like a modifier (small number with optional +/-), use -mod as the score.
    const abMap = {
        strength: {base:'str', mod:'strmod', score:['strscore','strmod'], modFields:['str']},
        dexterity: {base:'dex', mod:'dexmod', score:['dexscore','dexmod'], modFields:['dex']},
        constitution: {base:'con', mod:'conmod', score:['conscore','conmod'], modFields:['con']},
        intelligence: {base:'int', mod:'intmod', score:['intscore','intmod'], modFields:['int']},
        wisdom: {base:'wis', mod:'wismod', score:['wisscore','wismod'], modFields:['wis']},
        charisma: {base:'cha', mod:'chamod', score:['chascore','chamod'], modFields:['cha']},
    };
    for (const [ab, info] of Object.entries(abMap)) {
        // Strategy: check the "-mod" field first — many sheets store SCORE there
        const modFieldVal = find(...info.score);
        if (modFieldVal) {
            const scoreCandidate = parseInt(modFieldVal.replace(/[^\d]/g, ''));
            if (scoreCandidate >= 3 && scoreCandidate <= 30) {
                // Verify: the base field should look like a modifier, not a score
                const baseVal = find(...info.modFields);
                if (baseVal) {
                    const baseNum = parseInt(baseVal.replace(/[^\d\-]/g, ''));
                    // If base is a valid modifier for this score, we have the swapped layout
                    const expectedMod = Math.floor((scoreCandidate - 10) / 2);
                    if (baseNum === expectedMod || (baseNum >= -5 && baseNum <= 10 && scoreCandidate > 10 && baseNum < scoreCandidate)) {
                        char[ab] = scoreCandidate;
                        continue;
                    }
                }
                // Even without base confirmation, if it's clearly a score (3-30), use it
                char[ab] = scoreCandidate;
                continue;
            }
        }
        // Fallback: try the base field as score
        const baseVal = findInt(...info.modFields);
        if (baseVal >= 3 && baseVal <= 30) { char[ab] = baseVal; continue; }
        
        // Last resort: try direct field name patterns
        const directPatterns = [ab.substring(0,3)+'score', ab, ab.substring(0,3)];
        const directVal = findInt(...directPatterns);
        if (directVal >= 3 && directVal <= 30) { char[ab] = directVal; }
    }

    // Secondary pass: scan ALL fields for ability score patterns
    // Prefer "-mod" fields as scores (common in popular 5e PDF sheets)
    for (const [origKey, origVal] of Object.entries(fields)) {
        const k = origKey.toLowerCase().replace(/[\s_.\-()]+/g,'');
        const v = parseInt(String(origVal).replace(/[^\d]/g, ''));
        if (isNaN(v) || v < 3 || v > 30) continue;
        
        // Only match "-mod" suffix fields as scores (the swapped pattern)
        if (k === 'strmod' && char.strength === 10) char.strength = v;
        else if (k === 'dexmod' && char.dexterity === 10) char.dexterity = v;
        else if (k === 'conmod' && char.constitution === 10) char.constitution = v;
        else if (k === 'intmod' && char.intelligence === 10) char.intelligence = v;
        else if (k === 'wismod' && char.wisdom === 10) char.wisdom = v;
        else if (k === 'chamod' && char.charisma === 10) char.charisma = v;
    }

    // Combat
    char.ac = findInt('ac','armorclass','AC') || char.ac;
    char.initiative = findInt('initiative','init','Initiative') || char.initiative;
    char.speed = findInt('speed','Speed') || char.speed;
    char.hpMax = findInt('hpmax','maxhp','hitpointmaximum','hpmaximum','hitpoints','hp','HPMax') || char.hpMax;
    char.hpCurrent = findInt('hpcurrent','currenthp','currenthitpoints','HPCurrent') || char.hpMax;
    char.hpTemp = findInt('hptemp','temphp','temporaryhitpoints','HPTemp') || char.hpTemp;
    char.hitDice = find('hitdice','hdtotal','hitdicetotal','hd','HitDice') || char.hitDice;
    char.profBonus = findInt('profbonus','proficiencybonus','prof','ProfBonus') || char.profBonus;
    char.passivePerception = findInt('passive','passiveperception','passivewisdom','Passive') || char.passivePerception;
    char.inspiration = findInt('inspiration','Inspiration') || char.inspiration;

    // Saves — handle checkbox fields like "dex-save-check" and modifier fields like "dex-save"
    const saveMap = {str:'strength',dex:'dexterity',con:'constitution',int:'intelligence',wis:'wisdom',cha:'charisma'};
    for (const [short, full] of Object.entries(saveMap)) {
        // Check for checkbox-style proficiency fields
        const profField = find(short+'savingthrowprof',short+'saveprof','st'+full+'prof',short+'stprof',short+'savecheck');
        if (['Yes','true','1','On','true'].includes(profField)) char.saveProficiency[short] = true;
        // Also check original field names for checkbox patterns like "dex-save-check"
        for (const [origKey, origVal] of Object.entries(fields)) {
            const nk = origKey.toLowerCase().replace(/[\s_.\-()]+/g,'');
            if (nk === short+'savecheck' && (origVal === true || origVal === 'true' || origVal === 'Yes' || origVal === '1' || origVal === 'On')) {
                char.saveProficiency[short] = true;
            }
        }
        // Infer from save modifier vs ability modifier
        const saveMod = findInt(short+'save',short+'savingthrow','st'+full,'savingthrow'+short);
        if (saveMod !== 0) {
            const expectedUnprof = calcMod(char[full]);
            if (Math.abs(saveMod - expectedUnprof) >= char.profBonus - 1) char.saveProficiency[short] = true;
        }
    }

    // Skills
    const skillFieldMap = {
        acrobatics:['acrobatics'],animalHandling:['animalhandling','animal'],arcana:['arcana'],
        athletics:['athletics'],deception:['deception'],history:['history'],insight:['insight'],
        intimidation:['intimidation'],investigation:['investigation'],medicine:['medicine'],
        nature:['nature'],perception:['perception'],performance:['performance'],persuasion:['persuasion'],
        religion:['religion'],sleightOfHand:['sleightofhand','sleight'],stealth:['stealth'],survival:['survival'],
    };
    for (const [skill, patterns] of Object.entries(skillFieldMap)) {
        const profPatterns = patterns.flatMap(p=>[p+'prof',p+'check','chk'+p+'prof']);
        const profVal = find(...profPatterns);
        if (['Yes','true','1','On','true'].includes(profVal)) char.skills[skill] = 1;
        // Also check original fields for checkbox pattern like "deception-check"
        for (const [origKey, origVal] of Object.entries(fields)) {
            const nk = origKey.toLowerCase().replace(/[\s_.\-()]+/g,'');
            for (const p of patterns) {
                if (nk === p+'check' && (origVal === true || origVal === 'true' || origVal === 'Yes' || origVal === '1' || origVal === 'On')) {
                    char.skills[skill] = 1;
                }
            }
        }
        // Infer from skill modifier vs base modifier
        if (!char.skills[skill]) {
            const modVal = findInt(...patterns);
            const baseMod = calcMod(char[SKILL_ABILITY[skill]]);
            if (modVal !== 0 && modVal > baseMod) char.skills[skill] = 1;
        }
    }

    // Personality
    char.personalityTraits = find('personalitytraits','personality','traits') || char.personalityTraits;
    char.ideals = find('ideals') || char.ideals;
    char.bonds = find('bonds') || char.bonds;
    char.flaws = find('flaws') || char.flaws;

    // Features & Proficiencies
    char.featuresTraits = find('featuresandtraits','featurestraits','features','classfeatures','featuresandtraits1') || char.featuresTraits;
    const feat2 = find('featuresandtraits2','features2','additionalfeaturesandtraits');
    if (feat2) char.featuresTraits = (char.featuresTraits?char.featuresTraits+'\n\n':'') + feat2;

    char.proficienciesLanguages = find('proficiencieslang','proficienciesandlanguages','otherproficiencies',
        'proficiencies','otherproficienciesandlanguages') || char.proficienciesLanguages;
    const langs = find('languages');
    if (langs && !char.proficienciesLanguages.toLowerCase().includes(langs.toLowerCase())) {
        char.proficienciesLanguages = (char.proficienciesLanguages?char.proficienciesLanguages+'\n':'') + 'Languages: ' + langs;
    }
    const toolProf = find('toolproficiencies','tools');
    if (toolProf && !char.proficienciesLanguages.includes(toolProf)) {
        char.proficienciesLanguages = (char.proficienciesLanguages?char.proficienciesLanguages+'\n':'') + 'Tools: ' + toolProf;
    }

    // Equipment
    char.equipment = find('equipment','equipmentlist','gear','inventory') || char.equipment;
    const equip2 = find('equipment2','additionalequipment','treasureanditems');
    if (equip2) char.equipment = (char.equipment?char.equipment+'\n':'')+equip2;

    // Currency
    char.cp=findInt('cp','copperpieces','copper')||char.cp;
    char.sp=findInt('sp','silverpieces','silver')||char.sp;
    char.ep=findInt('ep','electrumpieces','electrum')||char.ep;
    char.gp=findInt('gp','goldpieces','gold')||char.gp;
    char.pp=findInt('pp','platinumpieces','platinum')||char.pp;

    // Attacks
    const attacks = [];
    for (let i = 1; i <= 3; i++) {
        const aName = find('atkname'+i,'weaponname'+i,'attackname'+i);
        const aBonus = find('atkbonus'+i,'attackbonus'+i);
        const aDmg = find('atkdamage'+i,'weapondamage'+i,'atkdamagetype'+i);
        if (aName) {
            attacks.push(`${aName}${aBonus?' | '+aBonus:''}${aDmg?' | '+aDmg:''}`);
            const equipDb = typeof EQUIPMENT !== 'undefined' ? EQUIPMENT : [];
            const wMatch = equipDb.find(e => e.name.toLowerCase() === aName.toLowerCase() && e.category === 'Weapon') ||
                           equipDb.find(e => e.category === 'Weapon' && aName.toLowerCase().includes(e.name.toLowerCase()));
            if (wMatch) {
                if (!char.equipmentItems.find(e => e.name === wMatch.name)) {
                    char.equipmentItems.push({
                        name:wMatch.name, qty:1, category:'Weapon',
                        weight:wMatch.weight||0, value:wMatch.value||'',
                        damage:wMatch.damage||aDmg||'', ac:0,
                        properties:wMatch.properties||'', weaponCategory:wMatch.weaponCategory||'',
                    });
                }
            } else {
                char.equipmentItems.push({
                    name:aName, qty:1, category:'Weapon',
                    weight:0, value:'', damage:aDmg||'', ac:0, properties:'',
                });
            }
        }
    }
    if (attacks.length) char.attacksSpellcasting = attacks.join('\n');

    // Spellcasting — handle -1 suffix (page 1) pattern common in multi-page spell sheets
    char.spellcastingClass = find('spellcastingclass','spellcastingclass1','castingclass') || char.charClass || '';
    char.spellcastingAbility = find('spellcastingability','spellcastingability1','castingability') || char.spellcastingAbility;
    char.spellSaveDC = findInt('spellsavedc','spellsavedc1','spelldc','savedc') || char.spellSaveDC;
    char.spellAttackBonus = findInt('spellattackbonus','spellattackbonus1','spellatkbonus','spellatk') || char.spellAttackBonus;

    for (let lvl = 1; lvl <= 9; lvl++) {
        // Try with -1 suffix (page 1 pattern: spell-slots-{lvl}-1) and without
        const max = findInt('spellslots'+lvl+'1','spellslots'+lvl,'slotmax'+lvl,'slotstotal'+lvl,'slots'+lvl);
        const used = findInt('slotsused'+lvl,'slotsexpended'+lvl,'slotsremaining'+lvl);
        if (max > 0) { char.spellSlots[lvl].max = max; char.spellSlots[lvl].used = used; }
    }

    // Spell names from fields — handle spells-{level}-{slot}-{page} pattern
    // Page 1 fields (suffix -1) are the primary spell page
    const spellNames = [];
    const processedSpellNames = new Set();
    
    // Fuzzy spell name matcher: handles typos like "Silvery Bard" -> "Silvery Barbs"
    function fuzzyMatchSpell(name) {
        const lower = name.toLowerCase().trim();
        // Exact match first
        let spell = SPELLS.find(s => s.name.toLowerCase() === lower);
        if (spell) return spell;
        // Try starts-with match (for truncated names)
        if (lower.length >= 4) {
            spell = SPELLS.find(s => s.name.toLowerCase().startsWith(lower));
            if (spell) return spell;
            // Try the input as prefix of spell name
            spell = SPELLS.find(s => lower.startsWith(s.name.toLowerCase().substring(0, lower.length)));
            if (spell && Math.abs(spell.name.length - name.length) <= 3) return spell;
        }
        // Levenshtein-like: allow 1-2 char difference
        for (const s of SPELLS) {
            const sLower = s.name.toLowerCase();
            if (Math.abs(sLower.length - lower.length) <= 2) {
                let diff = 0;
                const minLen = Math.min(sLower.length, lower.length);
                for (let i = 0; i < minLen; i++) { if (sLower[i] !== lower[i]) diff++; }
                diff += Math.abs(sLower.length - lower.length);
                if (diff <= 2) return s;
            }
        }
        return null;
    }
    
    for (const [k, v] of Object.entries(fields)) {
        const nk = norm(k);
        if ((nk.includes('spell')||nk.includes('cantrip')) && v && !nk.includes('slot') && !nk.includes('dc')
            && !nk.includes('bonus') && !nk.includes('ability') && !nk.includes('class') && !nk.includes('attack')
            && !nk.includes('remaining') && !nk.includes('save')) {
            const name = String(v).trim();
            if (name && name.length > 1 && name.length < 50 && !processedSpellNames.has(name.toLowerCase())) {
                processedSpellNames.add(name.toLowerCase());
                const spell = fuzzyMatchSpell(name);
                if (spell) {
                    if (!char.selectedSpells.find(s=>s.name===spell.name)) {
                        char.selectedSpells.push({name:spell.name,level:spell.level,school:spell.school,
                            ritual:spell.ritual,concentration:spell.concentration,sources:[]});
                    }
                } else spellNames.push(name);
            }
        }
    }
    if (spellNames.length) char.notes = (char.notes?char.notes+'\n\n':'')+'Spells from PDF (unmatched):\n'+spellNames.join('\n');

    // Bio
    char.backstory = find('backstory','characterbackstory','characterhistory') || char.backstory;
    char.alliesOrgs = find('alliesandorganizations','allies','factionname') || char.alliesOrgs;
    char.appearance = find('appearance','characterappearance') || char.appearance;
    char.age = find('age','characterage') || char.age;
    char.height = find('height','characterheight') || char.height;
    char.weight = find('weight','characterweight') || char.weight;
    char.eyes = find('eyes','eyecolor') || char.eyes;
    char.skin = find('skin','skincolor') || char.skin;
    char.hair = find('hair','haircolor') || char.hair;

    // Death saves
    for (let i=0;i<3;i++){
        const s=find('deathsavesuccess'+(i+1),'savesuccess'+(i+1));
        const f=find('deathsavefail'+(i+1),'savefailure'+(i+1),'failure'+(i+1));
        if(['Yes','true','1','On'].includes(s))char.deathSuccess[i]=true;
        if(['Yes','true','1','On'].includes(f))char.deathFail[i]=true;
    }

    if(char.hpMax>0&&char.hpCurrent<=0)char.hpCurrent=char.hpMax;
    if(char.profBonus<=0&&char.level>0)char.profBonus=profBonusByLevel(char.level);
}

function mapTextContent(text, char) {
    const fullText = text.replace(/\n/g,' ');
    const lines = text.split('\n');
    const classNames = CLASSES.map(c=>c.name);
    const raceNames = RACES.map(r=>r.name);

    for (const cls of classNames) {
        const re = new RegExp('\\b'+cls+'\\b','i');
        if (re.test(fullText) && !char.charClass) {
            char.charClass = cls;
            const lvlRe = new RegExp(cls+'\\s*(\\d{1,2})','i');
            const m = fullText.match(lvlRe);
            if (m) char.level = parseInt(m[1]);
        }
    }
    for (const race of raceNames) {
        if (race.length < 4) continue;
        const re = new RegExp('\\b'+race.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\b','i');
        if (re.test(fullText) && !char.race) char.race = race;
    }

    // Improved text-based ability score extraction
    for (const line of lines) {
        const l = line.trim();
        for (const [ab, field] of Object.entries({STR:'strength',DEX:'dexterity',CON:'constitution',INT:'intelligence',WIS:'wisdom',CHA:'charisma'})) {
            const fullName = {STR:'Strength',DEX:'Dexterity',CON:'Constitution',INT:'Intelligence',WIS:'Wisdom',CHA:'Charisma'}[ab];
            for (const pat of [
                new RegExp(ab+'\\s*:?\\s*(\\d{1,2})','i'),
                new RegExp(fullName+'\\s*:?\\s*(\\d{1,2})','i'),
                new RegExp(ab+'\\s+(\\d{1,2})\\s','i'),
            ]) {
                const m = l.match(pat);
                if (m && parseInt(m[1])>=3 && parseInt(m[1])<=30 && char[field]===10) char[field]=parseInt(m[1]);
            }
        }
    }
}

function matchToGameData(char) {
    if (char.race) {
        const rl = char.race.toLowerCase().trim();
        const m = RACES.find(r=>r.name.toLowerCase()===rl) || RACES.find(r=>rl.includes(r.name.toLowerCase()));
        if (m) { char.race = m.name; if(char.speed===30&&m.speed){char.speed=typeof m.speed==='object'?(m.speed.walk||30):m.speed;} }
    }
    if (char.charClass) {
        const cl = char.charClass.toLowerCase().trim();
        const m = CLASSES.find(c=>c.name.toLowerCase()===cl) || CLASSES.find(c=>cl.includes(c.name.toLowerCase()));
        if (m) {
            char.charClass = m.name;
            if (m.hd) { char.hitDice = char.level+'d'+m.hd.faces; char.hitDiceRemaining = char.level; }
            if (!Object.values(char.saveProficiency).some(v=>v) && m.proficiency) {
                for (const p of m.proficiency) char.saveProficiency[p] = true;
            }
            if (m.spellcastingAbility) {
                char.spellcastingClass = m.name;
                char.spellcastingAbility = m.spellcastingAbility.toUpperCase();
            }
            if (char.subclass) {
                const st = char.subclass.toLowerCase().trim();
                const sm = m.subclasses.find(sc=>sc.name.toLowerCase()===st) ||
                           m.subclasses.find(sc=>st.includes(sc.name.toLowerCase())) ||
                           m.subclasses.find(sc=>sc.shortName&&st.includes(sc.shortName.toLowerCase()));
                if (sm) char.subclass = sm.name;
                else if (/^\d+$/.test(char.subclass)) char.subclass = '';
            }
        }
    }
    if (char.background) {
        const bl = char.background.toLowerCase().trim();
        const m = BACKGROUNDS.find(b=>b.name.toLowerCase()===bl) || BACKGROUNDS.find(b=>bl.includes(b.name.toLowerCase()));
        if (m) char.background = m.name;
    }
    if (char.level>0 && char.profBonus<=0) char.profBonus = profBonusByLevel(char.level);

    // Parse equipment text into items
    if (char.equipment && typeof char.equipment === 'string') {
        const lines = char.equipment.split(/[\n,;]+/).map(l=>l.trim()).filter(l=>l);
        const equipDb = typeof EQUIPMENT !== 'undefined' ? EQUIPMENT : [];
        for (const line of lines) {
            const lineLower = line.toLowerCase().replace(/^\d+x?\s*/,'').replace(/\(.*\)/,'').trim();
            const qMatch = line.match(/^(\d+)x?\s*/);
            const qty = qMatch ? parseInt(qMatch[1]) : 1;
            const itemMatch = equipDb.find(e=>e.name.toLowerCase()===lineLower) || equipDb.find(e=>lineLower.includes(e.name.toLowerCase()));
            if (itemMatch) {
                if (!char.equipmentItems.find(e=>e.name===itemMatch.name)) {
                    char.equipmentItems.push({name:itemMatch.name,qty,category:itemMatch.category,
                        weight:itemMatch.weight||0,value:itemMatch.value||'',
                        damage:itemMatch.damage||'',ac:itemMatch.ac||0,
                        properties:itemMatch.properties||'',weaponCategory:itemMatch.weaponCategory||''});
                }
            } else if (line.length > 1) {
                char.equipmentItems.push({name:line,qty:1,category:'Other',weight:0,value:'',damage:'',ac:0});
            }
        }
        char.equipment = '';
    }
    if (!char.equipmentItems) char.equipmentItems = [];
    if (!char.pactSlots) char.pactSlots = {max:0,used:0,level:1};

    if (char.charClass === 'Warlock') {
        const ps = PACT_SLOTS[char.level];
        if (ps && char.pactSlots.max === 0) char.pactSlots = {max:ps[0],used:0,level:ps[1]};
    }
}

function parseFilename(filename, char) {
    const name = filename.replace(/\.pdf$/i,'');
    const dashParts = name.split(/\s*-\s*/);
    const classNames = CLASSES.map(c=>c.name);
    for (let i=0;i<dashParts.length;i++) {
        const part = dashParts[i].trim();
        for (const cls of classNames) {
            if (part.toLowerCase().includes(cls.toLowerCase())) {
                if (!char.charClass) char.charClass = cls;
                const bm = part.match(/\[([^\]]+)\]/);
                if (bm && !char.subclass) char.subclass = bm[1].trim();
                break;
            }
        }
        if (i>0 && !classNames.some(cls=>part.toLowerCase().includes(cls.toLowerCase()))) {
            if (part.length>2 && /[A-Z]/.test(part) && (!char.name||char.name==='New Character'))
                char.name = part.replace(/\[.*\]/,'').trim();
        }
    }
    if (dashParts.length>=3 && (!char.name||char.name==='New Character')) {
        char.name = dashParts[1].trim(); char.playerName = dashParts[0].trim();
    } else if (dashParts.length>=2 && (!char.name||char.name==='New Character')) {
        char.name = dashParts[0].trim();
    }
}

// ==================== SPELL SLOT BUTTON RENDERING ====================
function getSpellIconsForLevel(c, lvl) {
    const spells = (c.selectedSpells||[]).filter(s => s.level === lvl);
    if (!spells.length) return '';
    return '<div class="ss-spell-tags">' + spells.map(s => {
        return `<span class="ss-spell-tag" onclick="event.stopPropagation();openCastSpellPopup('${esc(s.name)}',${lvl})" title="Cast ${esc(s.name)}">${esc(s.name)}${s.concentration?' ⚡':''}</span>`;
    }).join('') + '</div>';
}

function renderCantripQuickcast(c) {
    const cantrips = (c.selectedSpells||[]).filter(s => s.level === 0);
    if (!cantrips.length) return '';
    if (!c.cantripSlots) c.cantripSlots = ['','','',''];
    while (c.cantripSlots.length < 4) c.cantripSlots.push('');
    const options = cantrips.map(s => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join('');
    return `<div class="cantrip-quickcast">
        <label>Cantrips:</label>
        ${[0,1,2,3].map(i => {
            let opts = options;
            if (c.cantripSlots[i]) opts = opts.replace('value="'+esc(c.cantripSlots[i])+'"','value="'+esc(c.cantripSlots[i])+'" selected');
            return `<select onchange="setCantripSlot(${i},this.value)" title="Quick cantrip ${i+1}"><option value="">—</option>${opts}</select>`;
        }).join('')}
    </div>`;
}

function renderSpellTracking(c) {
    const hasSlots = Object.values(c.spellSlots).some(s => s.max > 0);
    const hasPact = c.pactSlots && c.pactSlots.max > 0;
    if (!hasSlots && !hasPact) return '';
    const dc = c.spellSaveDC || calcSpellSaveDC(c);
    const atk = c.spellAttackBonus || calcSpellAttackBonus(c);
    let rows = '';
    if (hasPact) {
        const ps = c.pactSlots;
        let dots = '';
        for (let i = 0; i < ps.max; i++) {
            const isUsed = i < ps.used;
            dots += `<button class="spell-slot-btn ${isUsed?'used':''}" onclick="togglePactSlot(${i})" title="${isUsed?'Restore':'Use'} pact slot">${isUsed?'●':'○'}</button>`;
        }
        const pactLvlSpells = getSpellIconsForLevel(c, ps.level);
        rows += `<div class="spell-slot-row"><span class="ss-level">Pact(${ps.level})</span><div class="ss-dots">${dots}</div><span class="ss-count">${ps.used}/${ps.max}</span>${pactLvlSpells}</div>`;
    }
    for (let lvl = 1; lvl <= 9; lvl++) {
        const slot = c.spellSlots[lvl];
        if (slot.max <= 0) continue;
        let dots = '';
        for (let i = 0; i < slot.max; i++) {
            const isUsed = i < slot.used;
            dots += `<button class="spell-slot-btn ${isUsed?'used':''}" onclick="toggleSpellSlot(${lvl},${i})" title="${isUsed?'Restore':'Use'} level ${lvl} slot">${isUsed?'●':'○'}</button>`;
        }
        const spellIcons = getSpellIconsForLevel(c, lvl);
        rows += `<div class="spell-slot-row"><span class="ss-level">${lvl}${['st','nd','rd'][lvl-1]||'th'}</span><div class="ss-dots">${dots}</div><span class="ss-count">${slot.used}/${slot.max}</span>${spellIcons}</div>`;
    }
    return `<div class="spell-slot-section">
        <div class="spell-slot-header">
            <div class="ss-stat">Spell DC: <span>${dc}</span></div>
            <div class="ss-stat" style="margin-left:16px">Atk: <span>${modStr(atk)}</span></div>
            ${renderCantripQuickcast(c)}
        </div>
        <div class="box-title2">Spell Slots</div>
        <div class="spell-slot-grid">${rows}</div>
    </div>`;
}

function toggleSpellSlot(lvl, idx) {
    if (!currentChar) return;
    const slot = currentChar.spellSlots[lvl];
    if (idx < slot.used) {
        // Clicking a used slot restores it (sets used to idx)
        slot.used = idx;
    } else {
        // Clicking an available slot uses it (sets used to idx+1)
        slot.used = idx + 1;
    }
    saveCharacter(currentChar);
    render();
}

function togglePactSlot(idx) {
    if (!currentChar || !currentChar.pactSlots) return;
    const ps = currentChar.pactSlots;
    if (idx < ps.used) { ps.used = idx; } else { ps.used = idx + 1; }
    saveCharacter(currentChar);
    render();
}

function renderSpellSlotDots(lvl, c) {
    const slot = c.spellSlots[lvl];
    if (slot.max <= 0) return '';
    let dots = '';
    for (let i = 0; i < slot.max; i++) {
        const isUsed = i < slot.used;
        dots += `<button class="sc-slot-btn ${isUsed?'used':''}" onclick="event.stopPropagation();toggleSpellSlot(${lvl},${i})" title="${isUsed?'Restore':'Use'}">${isUsed?'●':'○'}</button>`;
    }
    return `<div class="sc-slot-dots">${dots}</div>`;
}

// ==================== CHARACTER SHEET RENDER (v7c restructured) ====================
function renderSheet() {
    if (!currentChar) { navigate('home'); return ''; }
    const c = currentChar;
    const abilities = ['strength','dexterity','constitution','intelligence','wisdom','charisma'];

    if (!c.pactSlots) c.pactSlots = {max:0,used:0,level:1};

    const isWarlock = c.charClass === 'Warlock';
    const maxPrep = getMaxPreparedSpells(c);
    const nonCantripSpells = (c.selectedSpells||[]).filter(s=>s.level>0).length;
    const prepLabel = PREPARED_CASTERS.includes(c.charClass) ? 'prepared' : 'known';
    const currentSkillCount = Object.values(c.skills).filter(v=>v>0).length;
    const maxSkills = getMaxSkillProficiencies(c);

    return `
    <div class="sheet-container">
        <div class="sheet-tabs">
            <button class="tab ${currentTab==='main'?'active':''}" onclick="switchTab('main',this)">Main</button>
            <button class="tab ${currentTab==='spells'?'active':''}" onclick="switchTab('spells',this)">Spells</button>
            <button class="tab ${currentTab==='bio'?'active':''}" onclick="switchTab('bio',this)">Background</button>
            <button class="tab ${currentTab==='notes'?'active':''}" onclick="switchTab('notes',this)">Notes</button>
        </div>
        <div class="sheet">

        <!-- HEADER (redesigned v7j — bigger portrait+icon) -->
        <div class="sheet-header">
            <div class="sh-grid-header">
                <div class="sh-portrait-thumb" onclick="document.getElementById('portrait-upload').click()" title="Change portrait">
                    ${c.portraitImage ? `<img src="${c.portraitImage}" class="portrait-img">` : `<svg viewBox="0 0 80 100" width="64" height="80"><ellipse cx="40" cy="30" rx="20" ry="22" fill="#888"/><ellipse cx="40" cy="95" rx="35" ry="35" fill="#888"/></svg>`}
                </div>
                <div class="sh-class-icon-big">${getClassSvgIconLarge(c.charClass)}</div>
                <div class="sh-header-fields">
                    <div class="sh-row">
                        <div class="sh-field"><button class="picker-btn-header" onclick="sheetPickClass()">${esc(c.charClass)||'Class'} ▼</button><label>Class</label>${c.classLevels && Object.keys(c.classLevels).length > 1 ? '<div class="multiclass-display">' + esc(getMulticlassDisplay(c)) + '</div>' : ''}</div>
                        <div class="sh-field sh-sm"><span class="picker-btn-header" style="cursor:pointer;text-align:center;display:block" onclick="openLevelPicker()">${c.level}</span><label>Level</label></div>
                        <div class="sh-field grow2"><input type="text" value="${esc(c.name)}" class="sh-name-input" onchange="updateField('name',this.value)"><label>Character Name</label></div>
                        <div class="sh-field"><button class="picker-btn-header" onclick="sheetPickAlignment()">${esc(c.alignment)||'Alignment'} ▼</button><label>Alignment</label></div>
                        <div class="sh-field sh-sm"><span class="picker-btn-header" style="cursor:pointer;text-align:center;display:block" onclick="openXpPicker()">${c.xp}</span><label>XP</label></div>
                    </div>
                    <div class="sh-row">
                        <div class="sh-field"><button class="picker-btn-header" onclick="sheetPickRace()">${esc(c.race)||'Race'} ▼</button><label>Race</label></div>
                        <div class="sh-field"><button class="picker-btn-header" onclick="sheetPickSubclass()">${esc(c.subclass)||'Subclass'} ▼</button><label>Subclass</label></div>
                        <div class="sh-field"><button class="picker-btn-header" onclick="sheetPickBg()">${esc(c.background)||'Background'} ▼</button><label>Background</label></div>
                    </div>
                </div>
            </div>
            <input type="file" id="portrait-upload" accept="image/*" style="display:none" onchange="uploadPortrait(this)">
        </div>

        <!-- TAB: MAIN (restructured — Stats | Skills+Saves side by side, equipment+treasure+prof moved here) -->
        <div class="tab-pane" id="tab-main" style="${currentTab==='main'?'':'display:none'}">
        <!-- MERGED META ROW -->
        <div class="tracker-bar-compact">
            <span class="tb-item tb-toggle ${c.inspiration ? 'tb-on' : ''}" onclick="updateField('inspiration',currentChar.inspiration?0:1);render()" title="Toggle Inspiration">🌟 Inspiration: ${c.inspiration ? 'ON' : 'OFF'}</span>
            <span class="tb-item">📊 Proficiency Bonus: <strong id="f-profBonus">+${c.profBonus}</strong></span>
            <span class="tb-item">👁️ Passive Perception: <strong id="f-passive">${calcPassivePerception(c)}</strong></span>
            <span class="tb-item">⚡ Concentration: <select class="conc-picklist" onchange="setConcentration(this.value);render()"><option value="">None</option>${(c.selectedSpells||[]).filter(s=>s.concentration).map(s=>`<option value="${esc(s.name)}"${c.concentratingOn===s.name?' selected':''}>${esc(s.name)}</option>`).join('')}</select></span>
            <span class="tb-item tb-toggle ${c.dmInspiration ? 'tb-on' : ''}" onclick="updateField('dmInspiration',!currentChar.dmInspiration);render()" title="Toggle DM Inspiration">🎲 DM Inspiration: ${c.dmInspiration ? 'ON' : 'OFF'}</span>



        </div>

        <div class="sheet-body-v7">

        <!-- LEFT: Ability Scores + Saving Throws + Skills + Proficiencies (merged column) -->
        <div class="col-left-merged">
            ${abilities.map(ab=>{
                const score=c[ab];const mod=calcMod(score);
                const short=ab.substring(0,3);
                const saveProf=c.saveProficiency[short];
                const saveMod=calcMod(c[ab])+(saveProf?c.profBonus:0);
                const AB_FULL={strength:'Strength',dexterity:'Dexterity',constitution:'Constitution',intelligence:'Intelligence',wisdom:'Wisdom',charisma:'Charisma'};
                const SKILL_MAP={strength:['athletics'],dexterity:['acrobatics','sleightOfHand','stealth'],constitution:[],intelligence:['arcana','history','investigation','nature','religion'],wisdom:['animalHandling','insight','medicine','perception','survival'],charisma:['deception','intimidation','performance','persuasion']};
                const skills=SKILL_MAP[ab]||[];
                return `<div class="unified-ab-box">
                    <div class="uab-header">
                        <span class="uab-name" onclick="showAbilityInfo('${ab}')">${AB_ICONS[ab]} ${AB_FULL[ab]}</span>
                        <div class="uab-score-mod">
                            <span class="uab-score" onclick="openNumberPicker('${ab}','${AB_FULL[ab]} Score',1,30,currentChar.${ab})">Score: ${score}</span>
                            <span class="uab-mod" id="mod-${ab}">${modStr(mod)}</span>
                        </div>
                    </div>
                    <div class="uab-row uab-save-row" onclick="showSaveInfo('${short}')" style="cursor:pointer" title="Click for info">
                        <span>Saving Throw</span>
                        <span style="margin-left:auto"></span>
                        <span class="uab-val" id="save-${short}">${modStr(saveMod)}</span>
                        <span class="prof-dot ${saveProf?'filled':''}"></span>
                    </div>
                    ${skills.map(key=>{
                        const prof=c.skills[key]||0;
                        const skillMod=calcMod(c[ab])+(c.profBonus*prof);
                        return `<div class="uab-row uab-skill-row" onclick="showSkillInfo('${key}')" style="cursor:pointer" title="Click for info">
                            <span class="prof-dot ${prof?(prof>=2?'expertise':'filled'):''}" style="flex-shrink:0"></span>
                            <span class="uab-val" id="skill-${key}">${modStr(skillMod)}</span>
                            <span>${SKILL_ICONS[key]||''} ${SKILL_LABELS[key]}</span>
                        </div>`;
                    }).join('')}
                </div>`;
            }).join('')}
        </div>

        <!-- MIDDLE: Combat + Attacks -->
        <div class="col-combat">
            <div class="combat-stat-row">
                <div class="combat-stat-box"><div class="cs-icon">🛡️</div><span style="font-size:1.2rem;font-weight:700">${c.ac}</span><div class="cs-label">Armor Class</div></div>
                <div class="combat-stat-box"><div class="cs-icon">⚡</div><span style="font-size:1.2rem;font-weight:700">${modStr(c.initiative)}</span><div class="cs-label">Initiative</div></div>
                <div class="combat-stat-box clickable-info" onclick="openNumberPicker('speed','Speed',5,60,currentChar.speed)"><div class="cs-icon">🏃</div><span style="font-size:1.2rem;font-weight:700">${c.speed} ft</span><div class="cs-label">Speed</div></div>
            </div>
            <div class="hp-row">
                <button class="hp-row-btn" onclick="openHpChange('damage')" title="Take Damage">➖</button>
                <div class="hp-row-display"><div class="cs-icon">❤️</div><div class="hp-values">${c.hpCurrent} / ${c.hpMax}${c.hpTemp>0?` <span class="hp-temp-badge">+ ${c.hpTemp} temp</span>`:''}</div><div class="cs-label">Hit Points</div></div>
                <button class="hp-row-btn" onclick="openHpChange('heal')" title="Heal">➕</button>
            </div>
            <div class="hd-ds-row">
                <div class="hd-inline">🎲 Hit Dice: <strong>${esc(c.hitDice)}</strong> (<span style="cursor:pointer;text-decoration:underline" onclick="openNumberPicker('hitDiceRemaining','Hit Dice Remaining',0,${c.level},currentChar.hitDiceRemaining)">${c.hitDiceRemaining}</span> left)</div>
                <div class="ds-inline">💀 Death Saves: ✓ ${[0,1,2].map(i=>`<span class="ds-circle ${c.deathSuccess[i]?'filled':''}" onclick="toggleDeath('deathSuccess',${i},${!c.deathSuccess[i]});render()">${c.deathSuccess[i]?'●':'○'}</span>`).join('')} ✗ ${[0,1,2].map(i=>`<span class="ds-circle ${c.deathFail[i]?'fail-filled':''}" onclick="toggleDeath('deathFail',${i},${!c.deathFail[i]});render()">${c.deathFail[i]?'●':'○'}</span>`).join('')}</div>
            </div>

            <div class="mid-box"><div class="box-title2">⚔️ Attacks</div>
                <button class="add-btn" onclick="sheetAddWeapon()">+ Add Weapon</button>
                ${renderWeaponTable(c)}
            </div>

            ${renderSpellTracking(c)}

            <div class="mid-box"><div class="box-title2">Attacks & Spellcasting Notes</div>
                <textarea rows="3" onchange="updateField('attacksSpellcasting',this.value)">${esc(c.attacksSpellcasting)}</textarea>
            </div>

        </div>

        <!-- COLUMN 3: Treasure + Equipment (split by category) -->
        <div class="col-equip">
            <div class="mid-box"><div class="box-title2">💰 Treasure <button class="tb-coin-toggle" onclick="toggleCurrencyVisibility()" title="Show/hide currency types">${getCurrencyExpanded() ? '▾ 💰' : '▸ 💰'}</button></div>
                ${renderTreasureSection(c)}
            </div>
            <div class="mid-box"><div class="box-title2">🛡️ Armor</div>
                <button class="add-btn" onclick="sheetAddEquipment()">+ Add</button>
                <div class="equip-list">${renderEquipmentByCategory(c,['Armor','Shield'])}</div>
            </div>
            <div class="mid-box"><div class="box-title2">⚔️ Weapons</div>
                <button class="add-btn" onclick="sheetAddEquipment()">+ Add</button>
                <div class="equip-list">${renderEquipmentByCategory(c,['Weapon'])}</div>
            </div>
            <div class="mid-box"><div class="box-title2">🎒 Misc</div>
                <button class="add-btn" onclick="sheetAddEquipment()">+ Add</button>
                <button class="add-btn" onclick="addCustomEquipment()">+ Custom</button>
                <div class="equip-list" id="equip-list">${renderEquipmentByCategory(c,['__misc__'])}</div>
            </div>
            <div class="equip-weight">Total weight: <strong id="equip-weight">${calcEquipWeight(c)}</strong> lb</div>
            <div class="mid-box"><div class="box-title2">Proficiencies & Languages <button class="bg-pick-btn" onclick="pickProficiencies()">📋 Pick</button></div>
                <textarea rows="3" onchange="updateField('proficienciesLanguages',this.value)">${esc(c.proficienciesLanguages)}</textarea>
            </div>
        </div>

        <div class="full-width-below"><div class="mid-box"><div class="box-title2">Features & Traits</div>
                <!-- Feats are now granted via Level Up ASI choices -->
                <textarea rows="6" id="f-featuresTraits" onchange="updateField('featuresTraits',this.value)">${esc(c.featuresTraits)}${c.additionalFeaturesTraits ? '\n\n' + esc(c.additionalFeaturesTraits) : ''}</textarea>
            </div></div>
        </div><!-- sheet-body-v7 -->
        </div><!-- tab-main -->

        <!-- TAB: SPELLS -->
        <div class="tab-pane" id="tab-spells" style="${currentTab==='spells'?'':'display:none'}">
            <div class="spell-header-bar">
                <div class="sh-field"><label>Casting Class</label><input type="text" value="${esc(c.spellcastingClass)}" onchange="updateField('spellcastingClass',this.value)"></div>
                <div class="sh-field"><label>Ability</label><input type="text" value="${esc(c.spellcastingAbility)}" onchange="updateField('spellcastingAbility',this.value)"></div>
                <div class="sh-field sh-sm"><label>Save DC</label><input type="number" value="${c.spellSaveDC}" id="f-spellDC" readonly style="background:#f5f5f5"></div>
                <div class="sh-field sh-sm"><label>Atk Bonus</label><input type="number" value="${c.spellAttackBonus}" id="f-spellAtk" readonly style="background:#f5f5f5"></div>
            </div>
            <div class="spell-info-bar">
                <span>Spells ${prepLabel}: <strong>${nonCantripSpells}</strong>${maxPrep!==Infinity?' / <strong>'+maxPrep+'</strong>':''}</span>
                ${isWarlock?`<span>Pact Slots: <strong>${c.pactSlots.max - c.pactSlots.used}</strong> / <strong>${c.pactSlots.max}</strong> (Level ${c.pactSlots.level})</span>`:''}
                ${c.concentratingOn ? `<span>⚡ Concentrating: <strong>${esc(c.concentratingOn)}</strong></span>` : ''}
            </div>
            ${isWarlock?`
            <div class="pact-slot-section">
                <strong>Pact Magic (Level ${c.pactSlots.level}):</strong>
                <div class="pact-slot-dots">
                    ${Array.from({length:c.pactSlots.max},(_, i)=>`<button class="pact-dot ${i<c.pactSlots.used?'used':''}" onclick="togglePactSlot(${i})" title="${i<c.pactSlots.used?'Restore':'Use'} pact slot">${i<c.pactSlots.used?'●':'○'}</button>`).join('')}
                </div>
                <span style="margin-left:8px;font-size:.8rem">${c.pactSlots.used}/${c.pactSlots.max}</span>
            </div>`:''}
            <div class="spell-grid">
                <div class="spell-card">
                    <div class="sc-header"><span>Cantrips</span><button class="spell-add" onclick="addSpell(0)">+ Add</button></div>
                    <div class="sc-body" id="spells-0">${renderSpellList(c,0)}</div>
                </div>
                ${[1,2,3,4,5,6,7,8,9].map(lvl=>`
                    <div class="spell-card">
                        <div class="sc-header">
                            <span>Level ${lvl}</span>
                            <div class="slot-track">${renderSpellSlotDots(lvl,c)}<span style="font-size:.7rem;margin-left:4px">${c.spellSlots[lvl].used}/${c.spellSlots[lvl].max}</span></div>
                            <button class="spell-add" onclick="addSpell(${lvl})">+ Add</button>
                        </div>
                        <div class="sc-body" id="spells-${lvl}">${renderSpellList(c,lvl)}</div>
                    </div>
                `).join('')}
            </div>
        </div>

        <!-- TAB: BACKGROUND (formerly Backstory — now includes personality) -->
        <div class="tab-pane" id="tab-bio" style="${currentTab==='bio'?'':'display:none'}">
            <div class="bio-sheet">
                <h2 class="bio-title">Background & Character Details</h2>
                <div class="bio-personality-grid">
                    ${[['Personality Traits','personalityTraits','personalityTraits'],['Ideals','ideals','ideals'],['Bonds','bonds','bonds'],['Flaws','flaws','flaws']].map(([label,field,bgKey])=>`
                        <div class="right-box"><div class="box-title2">${label} <button class="bg-pick-btn" onclick="pickFromBackground('${field}','${bgKey}')">📋 Pick</button></div>
                            <textarea rows="3" onchange="updateField('${field}',this.value)">${esc(c[field])}</textarea>
                        </div>
                    `).join('')}
                </div>
                <div class="bio-grid">
                    ${['age','height','weight','eyes','skin','hair'].map(f=>`
                        <div class="bio-field"><label>${f.charAt(0).toUpperCase()+f.slice(1)}</label>
                            <input type="text" value="${esc(c[f])}" onchange="updateField('${f}',this.value)">
                        </div>
                    `).join('')}
                </div>
                ${[['Appearance','appearance',4],['Backstory','backstory',10],['Allies & Organizations','alliesOrgs',4]].map(([label,field,rows])=>`
                    <div class="bio-ta"><label>${label}</label><textarea rows="${rows}" onchange="updateField('${field}',this.value)">${esc(c[field])}</textarea></div>
                `).join('')}
            </div>
        </div>

        <!-- TAB: NOTES -->
        <div class="tab-pane" id="tab-notes" style="${currentTab==='notes'?'':'display:none'}">
            <div class="notes-area">
                <h2>Session Notes</h2>
                <textarea rows="20" onchange="updateField('notes',this.value)">${esc(c.notes)}</textarea>
            </div>
        </div>

        </div><!-- sheet -->

        <div class="sheet-actions">
            <button class="btn btn-secondary" onclick="navigate('home')">← Characters</button>
            <button class="btn btn-primary" onclick="exportChar()">Export JSON</button>
            <button class="btn btn-primary" onclick="window.print()">Print / PDF</button>
            <label class="btn btn-secondary" style="cursor:pointer">Import JSON<input type="file" accept=".pdf,.json" onchange="handleUpload(this)" hidden></label>
            <button class="btn btn-danger" onclick="if(confirm('Delete ${esc(c.name)}?')){deleteCharacter('${c.id}');navigate('home')}">Delete</button>
            <span class="save-status" id="save-status">Auto-saved ✓</span>
        </div>
    </div>`;
}

function renderWeaponTable(c) {
    const weapons = (c.equipmentItems||[]).filter(i=>i.category==='Weapon');
    if (!weapons.length) return '<div class="spell-empty">No weapons — add from equipment</div>';
    return `<table class="weapon-table">
        <tr><th>Name</th><th>Atk Bonus</th><th>Damage</th><th></th></tr>
        ${weapons.map((w,i)=>{
            const idx = c.equipmentItems.indexOf(w);
            const atk = calcAttackBonus(c, w);
            return `<tr>
                <td>${esc(w.name)}</td>
                <td class="atk-bonus">${modStr(atk)}</td>
                <td>${esc(w.damage||'—')}</td>
                <td><button class="remove-btn" onclick="removeEquipment(${idx})">×</button></td>
            </tr>`;
        }).join('')}
    </table>`;
}

// v7: Spells are CLICKABLE — clicking opens detail popup
function renderSpellList(c, level) {
    const spells = (c.selectedSpells||[]).filter(s => s.level === level);
    if (!spells.length) return '<div class="spell-empty">No spells</div>';
    return spells.map(s => {
        // Determine if bonus action spell
        const fullSpell = SPELLS.find(sp => sp.name === s.name);
        const isBonusAction = fullSpell && fullSpell.castingTime && (fullSpell.castingTime.toLowerCase().startsWith('1 bonus') || fullSpell.castingTime.toLowerCase() === 'bonus action');
        const isReaction = fullSpell && fullSpell.castingTime && fullSpell.castingTime.toLowerCase().startsWith('1 reaction');
        return `
        <div class="spell-item">
            <span class="spell-name spell-clickable" onclick="openCastSpellPopup('${esc(s.name)}')" title="Click to cast">${esc(s.name)}${s.ritual?' <small>(R)</small>':''}${s.concentration?' <small>(C)</small>':''}${isBonusAction?' <small>(B)</small>':''}${isReaction?' <small>(Re)</small>':''}</span>
            ${s.concentration ? `<button class="conc-btn" onclick="event.stopPropagation();setConcentration('${esc(s.name)}')" title="Concentrate on this spell">⚡</button>` : ''}
            ${(s.sources||[]).map(src=>`<span class="badge badge-${src.type}">${src.label||src.name}</span>`).join('')}
            <button class="spell-remove" onclick="removeSpell('${esc(s.name)}',${level})">×</button>
        </div>
    `;}).join('');
}

function renderEquipmentList(c) {
    const items = c.equipmentItems||[];
    if (!items.length) return '<div class="spell-empty">No equipment</div>';
    return items.map((item,idx)=>{
        const d = [];
        if (item.ac) d.push('AC '+item.ac);
        if (item.damage) d.push(item.damage);
        if (item.weight) d.push(item.weight+'lb');
        if (item.value) d.push(item.value);
        const catClass = item.category==='Armor'?'racial':item.category==='Weapon'?'class':'info';
        const canEquip = (item.category==='Armor'||item.category==='Shield'||item.category==='Weapon');
        const eqBtn = canEquip ? `<button class="equip-toggle ${item.equipped?'equipped':''}" onclick="event.stopPropagation();toggleEquip(${idx})">${item.equipped?'✓':'—'}</button>` : '';
        return `<div class="equip-item clickable-info${item.equipped?' equipped-item':''}" onclick="showEquipmentInfo(${idx})" title="Click for details">
            <span class="equip-qty">${item.qty>1?item.qty+'x ':''}</span>
            <span class="equip-name">${esc(item.name)}</span>
            ${d.length?`<span class="equip-detail">${d.join(' · ')}</span>`:''}
            <span class="badge badge-${catClass}">${item.category||'Item'}</span>${eqBtn}
            <button class="spell-remove" onclick="event.stopPropagation();removeEquipment(${idx})">×</button>
        </div>`;
    }).join('');
}

function renderEquipmentByCategory(c, categories) {
    const items = c.equipmentItems||[];
    const isMisc = categories.includes('__misc__');
    const knownCats = ['Armor','Shield','Weapon'];
    const filtered = items.filter((item) => {
        const cat = item.category || 'Misc';
        if (isMisc) return !knownCats.includes(cat);
        return categories.includes(cat);
    });
    if (!filtered.length) return '<div class="spell-empty">None</div>';
    return filtered.map((item)=>{
        const idx = items.indexOf(item);
        const d = [];
        if (item.ac) d.push('AC '+item.ac);
        if (item.damage) d.push(item.damage);
        if (item.weight) d.push(item.weight+'lb');
        if (item.value) d.push(item.value);
        const catClass = item.category==='Armor'?'racial':item.category==='Weapon'?'class':'info';
        const canEquip = (item.category==='Armor'||item.category==='Shield'||item.category==='Weapon');
        const eqBtn = canEquip ? `<button class="equip-toggle ${item.equipped?'equipped':''}" onclick="event.stopPropagation();toggleEquip(${idx})">${item.equipped?'✓':'—'}</button>` : '';
        return `<div class="equip-item clickable-info${item.equipped?' equipped-item':''}" onclick="showEquipmentInfo(${idx})" title="Click for details">
            <span class="equip-qty">${item.qty>1?item.qty+'x ':''}</span>
            <span class="equip-name">${esc(item.name)}</span>
            ${d.length?`<span class="equip-detail">${d.join(' · ')}</span>`:''}
            ${eqBtn}
            <button class="spell-remove" onclick="event.stopPropagation();removeEquipment(${idx})">×</button>
        </div>`;
    }).join('');
}

function calcEquipWeight(c) {
    return (c.equipmentItems||[]).reduce((sum,i)=>sum+(i.weight||0)*(i.qty||1),0);
}
function refreshEquipList() {
    const el=$('#equip-list'); if(el)el.innerHTML=renderEquipmentList(currentChar);
    const w=$('#equip-weight'); if(w)w.textContent=calcEquipWeight(currentChar);
}

function toggleEquip(idx) {
    const item = currentChar.equipmentItems[idx];
    if (!item) return;
    item.equipped = !item.equipped;
    // Recalc AC from equipped armor/shield
    let baseAC = 10;
    const dexMod = calcMod(currentChar.dexterity);
    let shieldBonus = 0;
    (currentChar.equipmentItems||[]).forEach(it => {
        if (it.equipped && it.category === 'Armor' && it.ac) {
            baseAC = parseInt(it.ac) || 10;
            const aType = (it.armorType||it.name||'').toLowerCase();
            if (aType.includes('heavy') || aType.includes('chain mail') || aType.includes('splint') || aType.includes('plate') || aType.includes('ring mail')) {
                // heavy: no dex
            } else if (aType.includes('medium') || aType.includes('half plate') || aType.includes('scale') || aType.includes('breastplate') || aType.includes('hide')) {
                baseAC += Math.min(dexMod, 2);
            } else {
                baseAC += dexMod;
            }
        }
        if (it.equipped && it.category === 'Shield') shieldBonus = 2;
    });
    const equippedArmor = (currentChar.equipmentItems||[]).some(it=>it.equipped && it.category==='Armor');
    if (equippedArmor || shieldBonus) {
        if (!equippedArmor) baseAC = 10 + dexMod;
        currentChar.ac = baseAC + shieldBonus;
    }
    // Sync equipped weapons to attacks
    syncEquippedWeapons();
    saveCharacter(currentChar);
    if (typeof recalcAll === 'function') recalcAll();
    render();
}

function syncEquippedWeapons() {
    if (!currentChar) return;
    const equippedWeapons = (currentChar.equipmentItems||[]).filter(it=>it.equipped && it.category==='Weapon');
    // Add equipped weapons not already in attacks
    equippedWeapons.forEach(w => {
        const exists = (currentChar.attacks||[]).some(a=>a.name===w.name && a.fromEquip);
        if (!exists) {
            if (!currentChar.attacks) currentChar.attacks = [];
            const strMod = calcMod(currentChar.strength);
            const dexMod = calcMod(currentChar.dexterity);
            const isFinesse = (w.properties||'').toLowerCase().includes('finesse');
            const isRanged = (w.properties||'').toLowerCase().includes('range') || (w.weaponType||'').toLowerCase().includes('ranged');
            const abilMod = (isFinesse ? Math.max(strMod,dexMod) : isRanged ? dexMod : strMod);
            const atkBonus = abilMod + currentChar.profBonus;
            currentChar.attacks.push({name:w.name, bonus:atkBonus, damage:w.damage||'1d4', type:w.damageType||'', fromEquip:true});
        }
    });
    // Remove unequipped weapon attacks that were auto-added
    currentChar.attacks = (currentChar.attacks||[]).filter(a=>!a.fromEquip || equippedWeapons.some(w=>w.name===a.name));
}

// ==================== CONCENTRATION TRACKING ====================
function setConcentration(spellName) {
    if (!currentChar) return;
    currentChar.concentratingOn = spellName;
    saveCharacter(currentChar);
    render();
}

// ==================== SHEET ACTIONS ====================
function updateField(field, value) {
    if (!currentChar) return;
    currentChar[field] = value;
    saveCharacter(currentChar);
    const status=$('#save-status');
    if(status){status.textContent='Saved ✓';setTimeout(()=>{if(status)status.textContent='';},1500);}
}

function updateAbility(ab, value) {
    if (currentChar.abilityScoreLocked) {
        alert('Ability scores are locked. Unlock to edit.');
        render();
        return;
    }
    currentChar[ab] = value;
    const modEl=$(`#mod-${ab}`);
    if(modEl) modEl.textContent = modStr(calcMod(value));
    recalcAll();
    saveCharacter(currentChar);
}

function toggleAbilityLock(locked) {
    if (!currentChar) return;
    currentChar.abilityScoreLocked = locked;
    saveCharacter(currentChar);
    render();
}

function toggleSkillLock(locked) {
    if (!currentChar) return;
    currentChar.skillsLocked = locked;
    saveCharacter(currentChar);
    render();
}

function recalcAll() {
    if (!currentChar) return;
    const c = currentChar;
    const prof = c.profBonus;
    for (const [short,full] of Object.entries(AB_FROM_SHORT)) {
        const mod=calcMod(c[full])+(c.saveProficiency[short]?prof:0);
        const el=$(`#save-${short}`); if(el)el.textContent=modStr(mod);
    }
    for (const [key,ab] of Object.entries(SKILL_ABILITY)) {
        const mod=calcMod(c[ab])+(prof*(c.skills[key]||0));
        const el=$(`#skill-${key}`); if(el)el.textContent=modStr(mod);
    }
    // Derived stats (2014 rules)
    c.spellSaveDC = calcSpellSaveDC(c) || c.spellSaveDC;
    c.spellAttackBonus = calcSpellAttackBonus(c) || c.spellAttackBonus;
    c.passivePerception = calcPassivePerception(c);
    c.initiative = calcInitiative(c);
    
    const dcEl=$('#f-spellDC'); if(dcEl)dcEl.value=c.spellSaveDC;
    const atkEl=$('#f-spellAtk'); if(atkEl)atkEl.value=c.spellAttackBonus;
    const passEl=$('#f-passive'); if(passEl)passEl.value=c.passivePerception;
    const initEl=$('#f-initiative'); if(initEl)initEl.value=c.initiative;
    saveCharacter(c);
}

function toggleSaveProf(short, checked) { currentChar.saveProficiency[short]=checked; recalcAll(); saveCharacter(currentChar); }
function toggleSkillProf(key, checked) {
    if (currentChar.skillsLocked && checked) {
        const currentCount = Object.values(currentChar.skills).filter(v=>v>0).length;
        const max = getMaxSkillProficiencies(currentChar);
        if (currentCount >= max) {
            alert(`Skill proficiencies locked at maximum (${max}). Remove one first or unlock.`);
            render();
            return;
        }
    }
    currentChar.skills[key]=checked?1:0;
    recalcAll();
    saveCharacter(currentChar);
}
function toggleDeath(field, idx, checked) { currentChar[field][idx]=checked; saveCharacter(currentChar); }

function updateProfBonus() {
    const level=currentChar.level;
    currentChar.profBonus=profBonusByLevel(level);
    const el=$('#f-profBonus'); if(el)el.textContent='+'+currentChar.profBonus;
    // Update hit dice
    const cls = CLASSES.find(cl => cl.name === currentChar.charClass);
    if (cls) { currentChar.hitDice = level + 'd' + cls.hd.faces; }
    // Update spell slots
    applySpellSlots(currentChar);
    if (currentChar.charClass === 'Warlock') {
        const ps = PACT_SLOTS[level];
        if (ps) currentChar.pactSlots = {max:ps[0], used:currentChar.pactSlots?.used||0, level:ps[1]};
    }
    recalcAll(); saveCharacter(currentChar); render();
}

function updateSlot(lvl, type, value) { currentChar.spellSlots[lvl][type]=value; saveCharacter(currentChar); }
// Spell slot enforcement: can't use more than max
function updateSlotWithEnforcement(lvl, used) {
    const max = currentChar.spellSlots[lvl].max;
    if (used > max) { alert(`Only ${max} level ${lvl} slots available!`); return; }
    if (used < 0) used = 0;
    currentChar.spellSlots[lvl].used = used;
    saveCharacter(currentChar);
}

// Sheet pickers
function sheetPickRace() { openRacePicker(item=>{updateField('race',item.name);render();}); }
function sheetPickClass() {
    openClassPicker(item=>{
        updateField('charClass',item.name);
        if(item.raw.spellcastingAbility){currentChar.spellcastingClass=item.name;currentChar.spellcastingAbility=item.raw.spellcastingAbility.toUpperCase();}
        if(item.raw.proficiency){
            currentChar.saveProficiency={str:false,dex:false,con:false,int:false,wis:false,cha:false};
            for(const p of item.raw.proficiency)currentChar.saveProficiency[p]=true;
        }
        currentChar.hitDice=currentChar.level+'d'+item.raw.hd.faces;
        applySpellSlots(currentChar);
        if(item.name==='Warlock'){
            const ps=PACT_SLOTS[currentChar.level];
            if(ps)currentChar.pactSlots={max:ps[0],used:0,level:ps[1]};
        }
        recalcAll(); saveCharacter(currentChar); render();
    });
}
function sheetPickSubclass() {
    if(!currentChar.charClass){alert('Select a class first.');return;}
    openSubclassPicker(currentChar.charClass,item=>{updateField('subclass',item.name);render();});
}
function sheetPickBg() { openBackgroundPicker(item=>{updateField('background',item.name);render();}); }
function sheetPickFeat() {
    openFeatPicker(item=>{
        currentChar.selectedFeats.push({name:item.name,source:item.raw.source});
        const ta=$('#f-featuresTraits');
        const val=(ta?ta.value:currentChar.featuresTraits)||'';
        currentChar.featuresTraits=val+(val?'\n':'')+`[Feat] ${item.name}: ${(item.raw.entries||'').substring(0,200)}`;
        saveCharacter(currentChar); render();
    });
}

function sheetAddEquipment() {
    openEquipmentPicker(item=>{
        if(!currentChar.equipmentItems)currentChar.equipmentItems=[];
        const existing=currentChar.equipmentItems.find(e=>e.name===item.raw.name);
        if(existing){existing.qty=(existing.qty||1)+1;}
        else{
            currentChar.equipmentItems.push({
                name:item.raw.name,qty:1,category:item.raw.category,
                weight:item.raw.weight||0,value:item.raw.value||'',
                damage:item.raw.damage||'',ac:item.raw.ac||0,
                properties:item.raw.properties||'',weaponCategory:item.raw.weaponCategory||'',
                armorType:item.raw.armorType||'',
            });
        }
        saveCharacter(currentChar); render();
    });
}
function sheetAddWeapon() {
    const weapons = (typeof EQUIPMENT!=='undefined'?EQUIPMENT:[]).filter(e=>e.category==='Weapon');
    const items = weapons.map(item=>{
        const d=[];
        if(item.damage)d.push(item.damage);
        if(item.weight)d.push(item.weight+' lb');
        if(item.properties)d.push(item.properties);
        return {name:item.name,raw:item,sub:d.join(' · '),badges:[{type:'class',label:item.weaponCategory||'Weapon'}]};
    });
    openModal('Add Weapon',items,item=>{
        if(!currentChar.equipmentItems)currentChar.equipmentItems=[];
        if(!currentChar.equipmentItems.find(e=>e.name===item.raw.name)){
            currentChar.equipmentItems.push({
                name:item.raw.name,qty:1,category:'Weapon',
                weight:item.raw.weight||0,value:item.raw.value||'',
                damage:item.raw.damage||'',ac:0,
                properties:item.raw.properties||'',weaponCategory:item.raw.weaponCategory||'',
            });
        }
        saveCharacter(currentChar); render();
    });
}

function addCustomEquipment() {
    let html = '<div style="padding:12px;display:flex;flex-direction:column;gap:8px">';
    html += '<div><label style="font-size:.7rem;font-weight:700;text-transform:uppercase">Name</label><input type="text" id="ce-name" style="width:100%;padding:6px;border:1px solid #ccc;border-radius:4px;font-size:.9rem" placeholder="e.g. Cloak of Protection"></div>';
    html += '<div><label style="font-size:.7rem;font-weight:700;text-transform:uppercase">Category</label><select id="ce-category" style="width:100%;padding:6px;border:1px solid #ccc;border-radius:4px;font-size:.85rem"><option>Armor</option><option>Weapon</option><option>Shield</option><option>Wondrous</option><option selected>Misc</option></select></div>';
    html += '<div style="display:flex;gap:8px"><div style="flex:1"><label style="font-size:.7rem;font-weight:700;text-transform:uppercase">AC Bonus</label><input type="number" id="ce-ac" value="0" style="width:100%;padding:6px;border:1px solid #ccc;border-radius:4px;font-size:.85rem"></div>';
    html += '<div style="flex:1"><label style="font-size:.7rem;font-weight:700;text-transform:uppercase">Damage</label><input type="text" id="ce-damage" style="width:100%;padding:6px;border:1px solid #ccc;border-radius:4px;font-size:.85rem" placeholder="e.g. 1d8"></div>';
    html += '<div style="flex:1"><label style="font-size:.7rem;font-weight:700;text-transform:uppercase">Weight (lb)</label><input type="number" id="ce-weight" value="0" style="width:100%;padding:6px;border:1px solid #ccc;border-radius:4px;font-size:.85rem"></div></div>';
    html += '<div><label style="font-size:.7rem;font-weight:700;text-transform:uppercase">Properties / Effects</label><input type="text" id="ce-props" style="width:100%;padding:6px;border:1px solid #ccc;border-radius:4px;font-size:.85rem" placeholder="e.g. +1 to saving throws"></div>';
    html += '<div style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="ce-equip" checked style="width:16px;height:16px"><label style="font-size:.8rem">Equip immediately</label></div>';
    html += '<div style="text-align:right"><button class="btn btn-primary" onclick="submitCustomEquipment()">Add Item</button></div>';
    html += '</div>';
    showModal('Add Custom Equipment', html);
}
function submitCustomEquipment() {
    const nameEl = document.getElementById('ce-name');
    const catEl = document.getElementById('ce-category');
    const acEl = document.getElementById('ce-ac');
    const dmgEl = document.getElementById('ce-damage');
    const wtEl = document.getElementById('ce-weight');
    const propEl = document.getElementById('ce-props');
    const eqEl = document.getElementById('ce-equip');
    if (!nameEl || !nameEl.value.trim()) { alert('Please enter an item name.'); return; }
    const name = nameEl.value.trim();
    const category = catEl ? catEl.value : 'Misc';
    const ac = acEl ? (parseInt(acEl.value) || 0) : 0;
    const damage = dmgEl ? dmgEl.value.trim() : '';
    const weight = wtEl ? (parseFloat(wtEl.value) || 0) : 0;
    const properties = propEl ? propEl.value.trim() : '';
    const equipped = eqEl ? eqEl.checked : false;
    if (!currentChar.equipmentItems) currentChar.equipmentItems = [];
    currentChar.equipmentItems.push({name, qty:1, category, weight, value:'', damage, ac, acBonus: ac, properties, equipped});
    // If item has AC bonus, recalculate AC
    if (ac > 0 && equipped) {
        currentChar.ac = calcBaseAC(currentChar) + ac;
    }
    saveCharacter(currentChar); closeModal(); render();
}
function removeEquipment(idx) {
    if(!currentChar.equipmentItems)return;
    currentChar.equipmentItems.splice(idx,1);
    saveCharacter(currentChar); render();
}

function addSpell(level) {
    const c = currentChar;
    if (level > 0) {
        const maxPrep = getMaxPreparedSpells(c);
        const nonCantrips = (c.selectedSpells||[]).filter(s=>s.level>0).length;
        if (maxPrep !== Infinity && nonCantrips >= maxPrep) {
            alert(`You already have ${nonCantrips}/${maxPrep} spells. Remove one first.`);
            return;
        }
        const isWarlock = c.charClass === 'Warlock';
        if (isWarlock) {
            if (level > (c.pactSlots?.level || 0)) {
                alert(`Warlocks can only learn spells up to level ${c.pactSlots?.level||1}.`);
                return;
            }
        } else {
            if (c.spellSlots[level]?.max <= 0 && level > 0) {
                if (!confirm(`You have no level ${level} spell slots. Add anyway?`)) return;
            }
        }
    }

    openSpellPicker(level,c.charClass,c.subclass,c.race,item=>{
        const existing=c.selectedSpells.find(s=>s.name===item.name&&s.level===level);
        if(existing)return;
        c.selectedSpells.push({name:item.raw.name,level:item.raw.level,school:item.raw.school,
            ritual:item.raw.ritual,concentration:item.raw.concentration,sources:item.raw.sources||[]});
        saveCharacter(c);
        const container=$(`#spells-${level}`); if(container)container.innerHTML=renderSpellList(c,level);
    });
}
function removeSpell(name, level) {
    currentChar.selectedSpells=currentChar.selectedSpells.filter(s=>!(s.name===name&&s.level===level));
    if (currentChar.concentratingOn === name) currentChar.concentratingOn = '';
    saveCharacter(currentChar);
    const container=$(`#spells-${level}`); if(container)container.innerHTML=renderSpellList(currentChar,level);
}

function exportChar() {
    const blob=new Blob([JSON.stringify(currentChar,null,2)],{type:'application/json'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download=(currentChar.name||'character').replace(/[^a-zA-Z0-9]/g,'_')+'.json';
    a.click();URL.revokeObjectURL(url);
}

function switchTab(tab, btn) {
    currentTab = tab;
    $$('.tab-pane').forEach(t=>t.style.display='none');
    $$('.sheet-tabs .tab').forEach(t=>t.classList.remove('active'));
    const pane = $(`#tab-${tab}`);
    if (pane) pane.style.display = '';
    if (btn) btn.classList.add('active');
}

// ==================== REST & LEVEL ====================
function doLongRest() {
    if (!currentChar) return;
    const c = currentChar;
    c.hpCurrent = c.hpMax;
    const maxDice = Math.max(1, Math.ceil(c.level / 2));
    c.hitDiceRemaining = Math.min(c.level, (c.hitDiceRemaining||0) + maxDice);
    for (let i = 1; i <= 9; i++) c.spellSlots[i].used = 0;
    if (c.pactSlots) c.pactSlots.used = 0;
    c.deathSuccess = [false,false,false];
    c.deathFail = [false,false,false];
    c.concentratingOn = '';
    saveCharacter(c);
    render();
    alert('Long Rest complete! HP restored, spell slots restored, hit dice recovered.');
}

function doShortRest() {
    if (!currentChar) return;
    const c = currentChar;
    if (c.pactSlots) c.pactSlots.used = 0;

    const hitDieFaces = parseInt((c.hitDice||'1d8').split('d')[1]) || 8;
    const conMod = calcMod(c.constitution);
    const remaining = c.hitDiceRemaining || 0;

    const overlay = $('#short-rest-overlay');
    overlay.style.display = 'flex';
    const body = $('#short-rest-body');
    body.innerHTML = `
        <div class="sr-info">
            <p>Current HP: <strong>${c.hpCurrent} / ${c.hpMax}</strong></p>
            <p>Hit Dice remaining: <strong>${remaining}</strong> (d${hitDieFaces})</p>
            <p>CON modifier: <strong>${modStr(conMod)}</strong></p>
            ${c.charClass==='Warlock'?'<p>Pact slots restored!</p>':''}
        </div>
        <div class="sr-dice">
            <label>Spend how many hit dice?</label>
            <input type="number" id="sr-num-dice" value="1" min="0" max="${remaining}">
        </div>
        <div id="sr-result"></div>
        <div class="sr-buttons">
            <button class="btn btn-secondary" onclick="closeShortRest()">Cancel</button>
            <button class="btn btn-primary" onclick="rollShortRest(${hitDieFaces},${conMod},${remaining})">Roll & Heal</button>
        </div>
    `;
}

function rollShortRest(faces, conMod, maxDice) {
    const numDice = Math.min(parseInt($('#sr-num-dice')?.value)||0, maxDice);
    if (numDice <= 0) { closeShortRest(); saveCharacter(currentChar); render(); return; }
    let totalHeal = 0;
    const rolls = [];
    for (let i = 0; i < numDice; i++) {
        const roll = Math.floor(Math.random() * faces) + 1;
        const heal = Math.max(0, roll + conMod);
        rolls.push(`d${faces}=${roll}+${conMod}=${heal}`);
        totalHeal += heal;
    }
    currentChar.hpCurrent = Math.min(currentChar.hpMax, currentChar.hpCurrent + totalHeal);
    currentChar.hitDiceRemaining = Math.max(0, (currentChar.hitDiceRemaining||0) - numDice);
    saveCharacter(currentChar);
    const res = $('#sr-result');
    if (res) res.innerHTML = `<div class="sr-result">Rolled: ${rolls.join(', ')}<br>Healed <strong>${totalHeal}</strong> HP → now at <strong>${currentChar.hpCurrent}/${currentChar.hpMax}</strong></div>`;
    setTimeout(() => { closeShortRest(); render(); }, 2000);
}

function closeShortRest() { $('#short-rest-overlay').style.display = 'none'; }

function doLevelUp() {
    if (!currentChar) return;
    const c = currentChar;
    if (c.level >= 20) { alert('Already at max level (20).'); return; }
    
    // Initialize multiclass tracking if not present
    if (!c.classLevels) {
        c.classLevels = {};
        if (c.charClass) c.classLevels[c.charClass] = c.level;
    }
    
    // Show level-up dialog
    showLevelUpDialog(c);
}

function showLevelUpDialog(c) {
    const overlay = document.getElementById('info-popup-overlay');
    const title = document.getElementById('info-popup-title');
    const body = document.getElementById('info-popup-body');
    title.textContent = 'Level Up — Choose Class';
    
    if (!c.classLevels) {
        c.classLevels = {};
        if (c.charClass) c.classLevels[c.charClass] = c.level;
    }
    
    const currentClasses = Object.keys(c.classLevels);
    const totalLevel = c.level;
    
    // Build class options
    let html = '<div style="margin-bottom:12px;font-size:.85rem">';
    html += '<strong>Current Level:</strong> ' + totalLevel + '<br>';
    if (currentClasses.length > 0) {
        html += '<strong>Classes:</strong> ' + currentClasses.map(cl => cl + ' ' + c.classLevels[cl]).join(' / ') + '<br>';
    }
    html += '</div>';
    
    html += '<div style="font-weight:700;margin-bottom:8px">Level up in:</div>';
    html += '<div class="levelup-class-options">';
    
    // Current classes first
    for (const cls of currentClasses) {
        const classLvl = c.classLevels[cls];
        if (classLvl >= 20) continue;
        const features = getLevelUpSummary(cls, classLvl + 1, c.subclass);
        const featureText = features.map(f => f.label).join(', ') || 'No new features';
        html += `<div class="levelup-option" onclick="executeLevelUp('${cls}', false)">
            <div class="levelup-option-name">${cls} ${classLvl} → ${classLvl+1}</div>
            <div class="levelup-option-features">${featureText}</div>
        </div>`;
    }
    
    // Multiclass options (other classes)
    if (totalLevel < 20) {
        html += '<div style="margin-top:12px;font-weight:600;font-size:.8rem;color:#666;border-top:1px solid #ccc;padding-top:8px">Multiclass into:</div>';
        for (const cls of CLASSES) {
            if (currentClasses.includes(cls.name)) continue;
            const check = meetsMulticlassPrereqs(c, cls.name);
            const features = getLevelUpSummary(cls.name, 1, null);
            const featureText = features.map(f => f.label).join(', ') || 'Starting features';
            const mcProfs = MULTICLASS_PROFICIENCIES[cls.name];
            const profText = mcProfs ? [...mcProfs.armor, ...mcProfs.weapons, ...mcProfs.tools].filter(Boolean).join(', ') : '';
            html += `<div class="levelup-option ${check.ok ? '' : 'levelup-disabled'}" ${check.ok ? `onclick="executeLevelUp('${cls.name}', true)"` : ''}>
                <div class="levelup-option-name">${cls.name} (new) ${!check.ok ? '<span style="color:#c00;font-size:.75rem">— ' + check.reason + '</span>' : ''}</div>
                <div class="levelup-option-features">${featureText}</div>
                ${profText ? '<div class="levelup-option-profs">Gains: ' + profText + '</div>' : ''}
            </div>`;
        }
    }
    
    html += '</div>';
    html += '<div style="margin-top:12px;text-align:right"><button class="btn btn-secondary" onclick="document.getElementById(\'info-popup-overlay\').style.display=\'none\'">Cancel</button></div>';
    
    body.innerHTML = html;
    overlay.style.display = 'flex';
}

function executeLevelUp(className, isMulticlass) {
    const c = currentChar;
    if (!c) return;
    document.getElementById('info-popup-overlay').style.display = 'none';
    
    if (!c.classLevels) {
        c.classLevels = {};
        if (c.charClass) c.classLevels[c.charClass] = c.level;
    }
    
    // Apply the level up
    c.level++;
    if (isMulticlass) {
        c.classLevels[className] = 1;
        // Add multiclass proficiencies
        const mcProfs = MULTICLASS_PROFICIENCIES[className];
        if (mcProfs) {
            const profParts = [];
            if (mcProfs.armor.length) profParts.push('Armor: ' + mcProfs.armor.join(', '));
            if (mcProfs.weapons.length) profParts.push('Weapons: ' + mcProfs.weapons.join(', '));
            if (mcProfs.tools.length) profParts.push('Tools: ' + mcProfs.tools.join(', '));
            if (profParts.length) {
                c.proficienciesLanguages = (c.proficienciesLanguages || '') + '\n[Multiclass ' + className + '] ' + profParts.join('; ');
            }
        }
    } else {
        c.classLevels[className] = (c.classLevels[className] || 0) + 1;
    }
    
    const classLevel = c.classLevels[className];
    c.profBonus = profBonusByLevel(c.level);
    
    // HP gain from the class leveled
    const cls = CLASSES.find(cl => cl.name === className);
    if (cls) {
        const faces = cls.hd.faces;
        const hpGain = Math.ceil(faces / 2) + 1 + calcMod(c.constitution);
        c.hpMax += Math.max(1, hpGain);
        c.hpCurrent = c.hpMax;
    }
    
    // Update hit dice (combined)
    updateHitDice(c);
    
    // Spell slots (multiclass-aware)
    applySpellSlotsMulticlass(c);
    
    // Warlock pact slots
    if (c.classLevels['Warlock']) {
        const wlvl = c.classLevels['Warlock'];
        const ps = PACT_SLOTS[wlvl];
        if (ps) c.pactSlots = {max:ps[0], used:0, level:ps[1]};
    }
    
    c.spellSaveDC = calcSpellSaveDC(c);
    c.spellAttackBonus = calcSpellAttackBonus(c);
    c.passivePerception = calcPassivePerception(c);
    c.initiative = calcInitiative(c);
    
    // Get features for this level
    const features = getLevelUpSummary(className, classLevel, c.subclass);
    const hasASI = features.some(f => f.type === 'asi');
    
    // Add features to character
    const featureLabels = features.filter(f => f.type !== 'asi').map(f => f.label);
    if (featureLabels.length) {
        const featureText = '\n[' + className + ' ' + classLevel + '] ' + featureLabels.join(', ');
        c.featuresTraits = (c.featuresTraits || '') + featureText;
    }
    
    saveCharacter(c);
    render();
    
    // Show ASI/Feat dialog if applicable
    if (hasASI) {
        setTimeout(() => showASIDialog(c, className, classLevel, featureLabels), 100);
    } else {
        const classDisplay = getMulticlassDisplay(c);
        alert(`Leveled up to ${c.level}! (${classDisplay})\n\nNew features: ${featureLabels.join(', ') || 'None'}`);
    }
}

function updateHitDice(c) {
    if (!c.classLevels) return;
    const parts = [];
    for (const [cls, lvl] of Object.entries(c.classLevels)) {
        const classData = CLASSES.find(cl => cl.name === cls);
        if (classData) parts.push(lvl + 'd' + classData.hd.faces);
    }
    c.hitDice = parts.join(' + ');
    c.hitDiceRemaining = c.level;
}

function applySpellSlotsMulticlass(c) {
    if (!c.classLevels || Object.keys(c.classLevels).length <= 1) {
        // Single class - use original logic
        applySpellSlots(c);
        return;
    }
    // Multiclass spell slot calculation
    const casterLevel = getMulticlassCasterLevel(c);
    if (casterLevel > 0) {
        const slots = FULL_CASTER_SLOTS[casterLevel] || FULL_CASTER_SLOTS[20];
        for (let i = 0; i < 9; i++) {
            c.spellSlots[i+1].max = slots[i];
            c.spellSlots[i+1].used = 0;
        }
    } else {
        for (let i = 1; i <= 9; i++) { c.spellSlots[i].max = 0; c.spellSlots[i].used = 0; }
    }
}

function getMulticlassDisplay(c) {
    if (!c.classLevels || Object.keys(c.classLevels).length === 0) return c.charClass + ' ' + c.level;
    return Object.entries(c.classLevels).map(([cls, lvl]) => cls + ' ' + lvl).join(' / ');
}

function showASIDialog(c, className, classLevel, otherFeatures) {
    const overlay = document.getElementById('info-popup-overlay');
    const title = document.getElementById('info-popup-title');
    const body = document.getElementById('info-popup-body');
    title.textContent = 'Ability Score Improvement';
    
    let html = '<div style="margin-bottom:12px;font-size:.85rem">';
    html += '<strong>' + className + ' Level ' + classLevel + '</strong> — Choose one:';
    html += '</div>';
    
    // Option 1: ASI (+2 to one ability or +1 to two)
    html += '<div style="margin-bottom:16px">';
    html += '<div style="font-weight:700;margin-bottom:6px">Option 1: Ability Score Increase</div>';
    html += '<div style="font-size:.8rem;color:#666;margin-bottom:8px">+2 to one ability score, or +1 to two different ability scores (max 20)</div>';
    
    const abilities = ['strength','dexterity','constitution','intelligence','wisdom','charisma'];
    html += '<div id="asi-mode" style="margin-bottom:8px">';
    html += '<label style="margin-right:12px"><input type="radio" name="asiMode" value="plus2" checked onchange="updateASIMode()"> +2 to one</label>';
    html += '<label><input type="radio" name="asiMode" value="plus1" onchange="updateASIMode()"> +1 to two</label>';
    html += '</div>';
    
    html += '<div id="asi-selects">';
    html += '<select id="asi-ab1" style="padding:4px 8px;margin-right:8px">';
    for (const ab of abilities) {
        html += '<option value="' + ab + '">' + AB_SHORT[ab] + ' (' + c[ab] + ')' + (c[ab]>=20?' MAX':'') + '</option>';
    }
    html += '</select>';
    html += '<select id="asi-ab2" style="padding:4px 8px;display:none">';
    for (const ab of abilities) {
        html += '<option value="' + ab + '">' + AB_SHORT[ab] + ' (' + c[ab] + ')' + (c[ab]>=20?' MAX':'') + '</option>';
    }
    html += '</select>';
    html += '</div>';
    html += '<button class="btn btn-primary" style="margin-top:8px" onclick="applyASI()">Apply ASI</button>';
    html += '</div>';
    
    // Option 2: Feat
    html += '<div style="border-top:2px solid #000;padding-top:12px">';
    html += '<div style="font-weight:700;margin-bottom:6px">Option 2: Choose a Feat</div>';
    html += '<button class="btn btn-secondary" onclick="document.getElementById(\'info-popup-overlay\').style.display=\'none\';showFeatSelectionForASI()">Browse Feats</button>';
    html += '</div>';
    
    html += '<div style="margin-top:12px;text-align:right"><button class="btn btn-secondary" onclick="document.getElementById(\'info-popup-overlay\').style.display=\'none\'">Skip</button></div>';
    
    body.innerHTML = html;
    overlay.style.display = 'flex';
}

function updateASIMode() {
    const mode = document.querySelector('input[name="asiMode"]:checked')?.value;
    const sel2 = document.getElementById('asi-ab2');
    if (sel2) sel2.style.display = mode === 'plus1' ? 'inline-block' : 'none';
}

function applyASI() {
    const c = currentChar;
    if (!c) return;
    const mode = document.querySelector('input[name="asiMode"]:checked')?.value;
    const ab1 = document.getElementById('asi-ab1').value;
    
    if (mode === 'plus2') {
        if (c[ab1] >= 20) { alert(AB_SHORT[ab1] + ' is already at 20!'); return; }
        c[ab1] = Math.min(20, c[ab1] + 2);
    } else {
        const ab2 = document.getElementById('asi-ab2').value;
        if (c[ab1] >= 20) { alert(AB_SHORT[ab1] + ' is already at 20!'); return; }
        if (c[ab2] >= 20) { alert(AB_SHORT[ab2] + ' is already at 20!'); return; }
        c[ab1] = Math.min(20, c[ab1] + 1);
        c[ab2] = Math.min(20, c[ab2] + 1);
    }
    
    // Recalculate derived stats
    c.spellSaveDC = calcSpellSaveDC(c);
    c.spellAttackBonus = calcSpellAttackBonus(c);
    c.passivePerception = calcPassivePerception(c);
    c.initiative = calcInitiative(c);
    
    saveCharacter(c);
    document.getElementById('info-popup-overlay').style.display = 'none';
    render();
    alert('Ability Score Improvement applied!');
}

function showFeatSelectionForASI() {
    const c = currentChar;
    if (!c) return;
    
    // Filter feats by prerequisites
    const allFeats = (typeof FEATS !== 'undefined' ? FEATS : []);
    const items = allFeats.map(feat => {
        const prereqMet = checkFeatPrereqs(c, feat);
        const alreadyHas = (c.selectedFeats || []).some(f => f.name === feat.name);
        return {
            name: feat.name + (alreadyHas ? ' (already taken)' : '') + (!prereqMet.ok ? ' ✗' : ''),
            sub: feat.prerequisite || 'No prerequisite',
            desc: feat.description?.substring(0, 200) || '',
            raw: feat,
            disabled: !prereqMet.ok || alreadyHas,
            badges: [
                ...(!prereqMet.ok ? [{type:'warn', label: prereqMet.reason}] : []),
                ...(alreadyHas ? [{type:'info', label:'Already taken'}] : []),
            ]
        };
    }).sort((a,b) => (a.disabled?1:0) - (b.disabled?1:0) || a.name.localeCompare(b.name));
    
    openModal('Choose a Feat (ASI)', items, item => {
        if (item.disabled) return;
        const feat = item.raw;
        if (!c.selectedFeats) c.selectedFeats = [];
        c.selectedFeats.push({name: feat.name, source: feat.source});
        c.featuresTraits = (c.featuresTraits || '') + '\n[Feat] ' + feat.name + ': ' + (feat.description || '').substring(0, 200);
        saveCharacter(c);
        render();
        alert('Feat "' + feat.name + '" added!');
    });
}

function checkFeatPrereqs(c, feat) {
    if (!feat.prerequisite || feat.prerequisite === '') return {ok:true};
    const p = feat.prerequisite.toLowerCase();
    
    // Level requirements
    const lvlMatch = p.match(/level (\d+)/);
    if (lvlMatch && c.level < parseInt(lvlMatch[1])) return {ok:false, reason:'Level ' + lvlMatch[1] + ' required'};
    
    // Ability score requirements
    const abMatch = p.matchAll(/(strength|dexterity|constitution|intelligence|wisdom|charisma)\s+(\d+)/gi);
    for (const m of abMatch) {
        const ab = m[1].toLowerCase();
        const min = parseInt(m[2]);
        if ((c[ab] || 10) < min) return {ok:false, reason:ab + ' ' + min + ' required'};
    }
    
    // Spellcasting requirement
    if (p.includes('spellcasting') || p.includes('ability to cast')) {
        const cls = CLASSES.find(cl => cl.name === c.charClass);
        if (!cls || !cls.spellcastingAbility) return {ok:false, reason:'Spellcasting required'};
    }
    
    return {ok:true};
}


function doLevelDown() {
    if (!currentChar) return;
    const c = currentChar;
    if (c.level <= 1) { alert('Already at level 1.'); return; }
    
    // If multiclassed, ask which class to level down
    if (c.classLevels && Object.keys(c.classLevels).length > 1) {
        const classes = Object.entries(c.classLevels).filter(([_,lvl]) => lvl > 0);
        const choice = prompt('Which class to level down? (' + classes.map(([cls,lvl]) => cls + ' ' + lvl).join(', ') + ')');
        if (!choice) return;
        const matchedClass = classes.find(([cls]) => cls.toLowerCase() === choice.toLowerCase());
        if (!matchedClass) { alert('Class not found.'); return; }
        const [className, classLvl] = matchedClass;
        if (!confirm(`Level down ${className} from ${classLvl} to ${classLvl-1}?`)) return;
        
        const cls = CLASSES.find(cl => cl.name === className);
        if (cls) {
            const hpLoss = Math.ceil(cls.hd.faces/2) + 1 + calcMod(c.constitution);
            c.hpMax = Math.max(1, c.hpMax - Math.max(1, hpLoss));
        }
        c.level--;
        c.classLevels[className]--;
        if (c.classLevels[className] <= 0) delete c.classLevels[className];
    } else {
        if (!confirm(`Level down from ${c.level} to ${c.level-1}?`)) return;
        const cls = CLASSES.find(cl => cl.name === c.charClass);
        if (cls) {
            const hpLoss = Math.ceil(cls.hd.faces/2) + 1 + calcMod(c.constitution);
            c.hpMax = Math.max(1, c.hpMax - Math.max(1, hpLoss));
        }
        c.level--;
        if (c.classLevels && c.classLevels[c.charClass]) c.classLevels[c.charClass]--;
    }
    
    c.profBonus = profBonusByLevel(c.level);
    updateHitDice(c);
    c.hpCurrent = Math.min(c.hpCurrent, c.hpMax);
    applySpellSlotsMulticlass(c);
    if (c.classLevels?.['Warlock']) {
        const ps = PACT_SLOTS[c.classLevels['Warlock']];
        if (ps) c.pactSlots = {max:ps[0], used:0, level:ps[1]};
    }
    c.spellSaveDC = calcSpellSaveDC(c);
    c.spellAttackBonus = calcSpellAttackBonus(c);
    c.passivePerception = calcPassivePerception(c);
    c.initiative = calcInitiative(c);
    saveCharacter(c);
    render();
    alert(`Leveled down to ${c.level}. (${getMulticlassDisplay(c)})`);
}


// ==================== RITUAL CASTING ====================
function doCastRitual(spellName) {
    const c = currentChar;
    if (!c) return;
    const spell = SPELLS.find(s => s.name === spellName);
    if (!spell || !spell.ritual) { alert('This spell cannot be cast as a ritual.'); return; }
    // Ritual casting does NOT consume a spell slot
    // It takes 10 minutes longer than normal casting time
    if (spell.concentration) {
        if (c.concentratingOn && c.concentratingOn !== spellName) {
            if (!confirm(`You are concentrating on "${c.concentratingOn}". Replace with "${spellName}"?`)) return;
        }
        c.concentratingOn = spellName;
    }
    saveCharacter(c);
    closeSpellDetail();
    render();
    alert(`Cast ${spellName} as a ritual (no spell slot used, +10 min casting time).`);
}

// ==================== INFO POPUP SYSTEM ====================
function openInfoPopup(title, content) {
    let overlay = document.getElementById('info-popup-overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'info-popup-overlay';
        overlay.className = 'modal-overlay';
        overlay.style.display = 'none';
        overlay.onclick = (e) => { if (e.target === overlay) overlay.style.display = 'none'; };
        overlay.innerHTML = `<div class="modal" style="max-width:500px">
            <div class="modal-header"><h2 id="info-popup-title"></h2><button class="modal-close" onclick="document.getElementById('info-popup-overlay').style.display='none'">×</button></div>
            <div class="modal-body" id="info-popup-body" style="padding:16px;font-size:.85rem;line-height:1.5"></div>
        </div>`;
        document.body.appendChild(overlay);
    }
    document.getElementById('info-popup-title').textContent = title;
    document.getElementById('info-popup-body').innerHTML = content;
    overlay.style.display = 'flex';
}

const SKILL_INFO = {
    acrobatics: {ability:'Dexterity', desc:'Covers attempts to stay on your feet in tricky situations, like running across ice, balancing on a tightrope, or staying upright on a rocking ship.', examples:'Balance on narrow surface, escape grapple with agility, perform acrobatic stunts'},
    animalHandling: {ability:'Wisdom', desc:'Calm a domesticated animal, keep a mount from getting spooked, or intuit an animal\'s intentions.', examples:'Calm a frightened horse, train a hawk, sense a beast\'s mood'},
    arcana: {ability:'Intelligence', desc:'Measures your ability to recall lore about spells, magic items, eldritch symbols, magical traditions, planes of existence, and the inhabitants of those planes.', examples:'Identify a spell being cast, recall magical lore, recognize a magical effect'},
    athletics: {ability:'Strength', desc:'Covers difficult situations you encounter while climbing, jumping, or swimming.', examples:'Climb a sheer cliff, hold on during an earthquake, swim in treacherous currents, long/high jumps'},
    deception: {ability:'Charisma', desc:'Determines whether you can convincingly hide the truth, whether through words or actions.', examples:'Mislead someone, maintain a disguise, fast-talk a guard, con a merchant'},
    history: {ability:'Intelligence', desc:'Measures your ability to recall lore about historical events, legendary people, ancient kingdoms, past disputes, recent wars, and lost civilizations.', examples:'Recall a historical event, identify a royal lineage, know about an ancient war'},
    insight: {ability:'Wisdom', desc:'Measures your ability to determine the true intentions of a creature, such as when searching for a lie or predicting someone\'s next move.', examples:'Detect a lie, predict behavior, read body language, sense hidden motives'},
    intimidation: {ability:'Charisma', desc:'When you attempt to influence someone through overt threats, hostile actions, and physical violence.', examples:'Threaten a prisoner, scare off thugs, demand compliance through menace'},
    investigation: {ability:'Intelligence', desc:'When you look around for clues and make deductions based on those clues.', examples:'Search for hidden compartments, deduce clues at a crime scene, research in a library'},
    medicine: {ability:'Wisdom', desc:'Lets you try to stabilize a dying companion or diagnose an illness.', examples:'Stabilize a dying creature, diagnose a disease, determine cause of death'},
    nature: {ability:'Intelligence', desc:'Measures your ability to recall lore about terrain, plants and animals, the weather, and natural cycles.', examples:'Identify a plant or animal, predict weather, recall terrain features'},
    perception: {ability:'Wisdom', desc:'Lets you spot, hear, or otherwise detect the presence of something. It measures your general awareness.', examples:'Spot a hidden creature, hear approaching enemies, notice a trap, detect a secret door'},
    performance: {ability:'Charisma', desc:'Determines how well you can delight an audience with music, dance, acting, storytelling, or some other form of entertainment.', examples:'Play an instrument, tell a captivating story, perform a dance, act in a play'},
    persuasion: {ability:'Charisma', desc:'When you attempt to influence someone or a group with tact, social graces, or good nature.', examples:'Negotiate a peace, convince a noble, inspire a crowd, haggle for a price'},
    religion: {ability:'Intelligence', desc:'Measures your ability to recall lore about deities, rites and prayers, religious hierarchies, holy symbols, and the practices of secret cults.', examples:'Identify a deity\'s symbol, recall religious doctrine, recognize a cult\'s practices'},
    sleightOfHand: {ability:'Dexterity', desc:'Whenever you attempt an act of legerdemain or manual trickery, such as planting something on someone or concealing an object on your person.', examples:'Pick a pocket, plant evidence, palm an object, perform a card trick'},
    stealth: {ability:'Dexterity', desc:'When you attempt to conceal yourself from enemies, slink past guards, slip away without being noticed, or sneak up on someone.', examples:'Hide from enemies, move silently, shadow someone, avoid detection'},
    survival: {ability:'Wisdom', desc:'Follow tracks, hunt wild game, guide your group through frozen wastelands, identify signs of nearby creatures, predict the weather, or avoid quicksand.', examples:'Track a creature, find food and water, navigate wilderness, identify tracks'},
};

const SAVE_INFO = {
    str: {name:'Strength', desc:'Resisting physical force. Used against effects that try to move you, restrain you, or physically overpower you.', examples:'Resisting being pushed, breaking free of restraints, withstanding a crushing force'},
    dex: {name:'Dexterity', desc:'Dodging out of the way of danger. The most common save — used against area effects like fireballs, breath weapons, and traps.', examples:'Dodging a fireball, avoiding a trap, evading a dragon\'s breath weapon'},
    con: {name:'Constitution', desc:'Enduring physical punishment. Used against poison, disease, death effects, and maintaining concentration.', examples:'Resisting poison, surviving extreme cold, maintaining spell concentration'},
    int: {name:'Intelligence', desc:'Resisting mental attacks that can be overcome with logic and memory. Relatively rare.', examples:'Seeing through certain illusions, resisting psionic attacks, recognizing mental manipulation'},
    wis: {name:'Wisdom', desc:'Resisting effects that charm, frighten, or mentally dominate. Very common and important save.', examples:'Resisting charm/fear effects, seeing through illusions, withstanding domination'},
    cha: {name:'Charisma', desc:'Resisting effects that affect your sense of self or try to subsume your personality.', examples:'Resisting banishment, withstanding possession, maintaining identity against magic'},
};

const ABILITY_INFO = {
    strength: {name:'Strength (STR)', desc:'Natural athleticism, bodily power. Determines melee attack/damage with most weapons, carrying capacity, and Athletics checks.', affects:'Melee attacks, carrying capacity, Athletics, jump distance, grappling'},
    dexterity: {name:'Dexterity (DEX)', desc:'Physical agility, reflexes, balance, poise. Affects AC, initiative, ranged attacks, and finesse weapons.', affects:'AC (unarmored/light/medium), Initiative, Ranged attacks, Finesse weapons, Acrobatics, Stealth, Sleight of Hand'},
    constitution: {name:'Constitution (CON)', desc:'Health, stamina, vital force. Determines hit points and Constitution saves (concentration).', affects:'Hit points per level, Concentration saves, resistance to poison/disease'},
    intelligence: {name:'Intelligence (INT)', desc:'Mental acuity, accuracy of recall, ability to reason. Spellcasting ability for Wizards.', affects:'Wizard spellcasting, Arcana, History, Investigation, Nature, Religion'},
    wisdom: {name:'Wisdom (WIS)', desc:'Awareness, intuition, insight. Spellcasting ability for Clerics, Druids, and Rangers.', affects:'Cleric/Druid/Ranger spellcasting, Perception, Insight, Medicine, Survival, Animal Handling'},
    charisma: {name:'Charisma (CHA)', desc:'Force of personality, persuasiveness, leadership. Spellcasting ability for Bards, Paladins, Sorcerers, and Warlocks.', affects:'Bard/Paladin/Sorcerer/Warlock spellcasting, Deception, Intimidation, Performance, Persuasion'},
};

function showSkillInfo(key) {
    const info = SKILL_INFO[key];
    if (!info) return;
    const label = SKILL_LABELS[key] || key;
    openInfoPopup(label, `
        <p><strong>Ability:</strong> ${info.ability}</p>
        <p>${info.desc}</p>
        <p><strong>Examples:</strong> ${info.examples}</p>
    `);
}
function showSaveInfo(short) {
    const info = SAVE_INFO[short];
    if (!info) return;
    openInfoPopup(info.name + ' Save', `<p>${info.desc}</p><p><strong>Examples:</strong> ${info.examples}</p>`);
}
function showAbilityInfo(ab) {
    const info = ABILITY_INFO[ab];
    if (!info) return;
    openInfoPopup(info.name, `<p>${info.desc}</p><p><strong>Affects:</strong> ${info.affects}</p>`);
}
function showEquipmentInfo(idx) {
    if (!currentChar || !currentChar.equipmentItems) return;
    const item = currentChar.equipmentItems[idx];
    if (!item) return;
    const lines = [`<p><strong>Category:</strong> ${item.category || 'Item'}</p>`];
    if (item.damage) lines.push(`<p><strong>Damage:</strong> ${item.damage}</p>`);
    if (item.ac) lines.push(`<p><strong>AC:</strong> ${item.ac}${item.armorType?' ('+item.armorType+')':''}</p>`);
    if (item.weight) lines.push(`<p><strong>Weight:</strong> ${item.weight} lb</p>`);
    if (item.value) lines.push(`<p><strong>Value:</strong> ${item.value}</p>`);
    if (item.properties) lines.push(`<p><strong>Properties:</strong> ${item.properties}</p>`);
    if (item.weaponCategory) lines.push(`<p><strong>Type:</strong> ${item.weaponCategory}</p>`);
    // Try to find in EQUIPMENT db for description
    const dbItem = (typeof EQUIPMENT !== 'undefined' ? EQUIPMENT : []).find(e => e.name === item.name);
    if (dbItem && dbItem.description) lines.push(`<p>${dbItem.description}</p>`);
    openInfoPopup(item.name, lines.join(''));
}
function showProfInfo() {
    if (!currentChar) return;
    openInfoPopup('Proficiencies & Languages', `<pre style="white-space:pre-wrap;font-family:inherit">${esc(currentChar.proficienciesLanguages || 'None')}</pre>`);
}

// ==================== CLASS ART ICONS ====================
const CLASS_ICONS = {
    Barbarian: '⚔️', Bard: '🎵', Cleric: '✝️', Druid: '🌿', Fighter: '🛡️',
    Monk: '👊', Paladin: '⚜️', Ranger: '🏹', Rogue: '🗡️',
    Sorcerer: '✨', Warlock: '👁️', Wizard: '🔮', Artificer: '⚙️',
};
function getClassIcon(className) { return CLASS_ICONS[className] || '⚔️'; }
function getClassSvgIcon(cls) {
    const svg = CLASS_SVG_ART && CLASS_SVG_ART[cls];
    if (!svg) return '<span class="sh-class-icon">' + getClassIcon(cls) + '</span>';
    return '<span class="topbar-class-svg">' + svg + '</span>';
}
function getClassSvgIconLarge(cls) {
    const svg = CLASS_SVG_ART && CLASS_SVG_ART[cls];
    if (!svg) return '<span style="font-size:3rem">' + getClassIcon(cls) + '</span>';
    // Remove hardcoded width/height, let CSS container handle sizing
    return svg.replace(/\s*width="[^"]*"/g, '').replace(/\s*height="[^"]*"/g, '');
}

// ==================== ALIGNMENT PICKER ====================
const ALIGNMENTS = ['Lawful Good','Neutral Good','Chaotic Good','Lawful Neutral','True Neutral','Chaotic Neutral','Lawful Evil','Neutral Evil','Chaotic Evil'];
function sheetPickAlignment() {
    let html = '<div style="max-height:400px;overflow:auto">';
    ALIGNMENTS.forEach(a => {
        html += '<div class="pick-option" onclick="updateField(\'alignment\',\'' + a + '\');closeModal();render()" style="padding:10px;border-bottom:1px solid #ddd;cursor:pointer;font-size:.9rem">' + a + '</div>';
    });
    html += '</div>';
    showModal('Choose Alignment', html);
}

// ==================== SHOW MODAL (HTML content) ====================
function showModal(title, htmlContent) {
    $('#modal-title').textContent = title;
    const search = $('#modal-search');
    if (search) search.style.display = 'none';
    $('#modal-body').innerHTML = htmlContent;
    $('#modal-overlay').style.display = 'flex';
}

// ==================== PROFICIENCIES PICKER ====================
function pickProficiencies() {
    if (!currentChar) return;
    const race = currentChar.race;
    const bg = currentChar.background;
    const allProfs = [];
    // Gather from gamedata
    if (window.GAME_DATA) {
        const raceData = (window.GAME_DATA.races||[]).find(r=>r.name===race);
        if (raceData) {
            (raceData.proficiencies||[]).forEach(p => allProfs.push({name:p,source:'Race: '+race}));
            (raceData.languages||[]).forEach(l => allProfs.push({name:l,source:'Race: '+race}));
        }
        const bgData = (window.GAME_DATA.backgrounds||[]).find(b=>b.name===bg);
        if (bgData) {
            (bgData.proficiencies||[]).forEach(p => allProfs.push({name:p,source:'Background: '+bg}));
            (bgData.languages||[]).forEach(l => allProfs.push({name:l,source:'Background: '+bg}));
        }
    }
    if (!allProfs.length) { alert('No proficiency data found for current race/background'); return; }
    const current = (currentChar.proficienciesLanguages||'').toLowerCase();
    let html = '<div style="max-height:400px;overflow:auto">';
    allProfs.forEach((p, i) => {
        const has = current.includes(p.name.toLowerCase());
        html += '<div class="pick-option" style="padding:8px;border-bottom:1px solid #ddd;cursor:pointer;display:flex;align-items:center;gap:8px" onclick="toggleProficiency('+i+')" id="prof-pick-'+i+'">';
        html += '<span style="font-size:1.1rem">'+(has?'☑':'☐')+'</span>';
        html += '<span><strong>'+p.name+'</strong> <small style="color:#888">'+p.source+'</small></span>';
        html += '</div>';
    });
    html += '</div><div style="padding:8px;text-align:right"><button class="btn btn-primary" onclick="closeModal()">Done</button></div>';
    window._profPickerData = allProfs;
    showModal('Proficiencies & Languages', html);
}
function toggleProficiency(idx) {
    const p = window._profPickerData[idx];
    if (!p) return;
    let current = currentChar.proficienciesLanguages || '';
    if (current.toLowerCase().includes(p.name.toLowerCase())) {
        // Remove it
        current = current.split(/[,;\n]/).filter(s=>s.trim().toLowerCase()!==p.name.toLowerCase()).join(', ');
    } else {
        current = current ? current + ', ' + p.name : p.name;
    }
    currentChar.proficienciesLanguages = current;
    saveCharacter(currentChar);
    render();
    pickProficiencies(); // Re-open to refresh state
}

// ==================== PORTRAIT UPLOAD ====================
function uploadPortrait(input) {
    const file = input.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        currentChar.portraitImage = e.target.result;
        saveCharacter(currentChar);
        render();
    };
    reader.readAsDataURL(file);
    input.value = '';
}

// ==================== CLASS SVG ART ====================
const CLASS_SVG_ART = {
Barbarian:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="brbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#8B0000"/><stop offset="100%" stop-color="#2a0000"/></linearGradient></defs><g><path d="M75 10 L25 70 L45 70 L30 130 L55 95 L40 95 L75 40 L110 95 L95 95 L120 130 L105 70 L125 70Z" fill="url(#brbg)" stroke="#111" stroke-width="2"/><path d="M50 135 L75 160 L100 135" fill="none" stroke="#8B0000" stroke-width="4" stroke-linecap="round"/><path d="M40 145 L75 175 L110 145" fill="none" stroke="#600" stroke-width="3" stroke-linecap="round"/><circle cx="75" cy="25" r="6" fill="#ff4444" opacity=".8"/></g></svg>`,
Bard:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="brdbg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#DAA520"/><stop offset="100%" stop-color="#8B6914"/></linearGradient></defs><g><ellipse cx="55" cy="140" rx="28" ry="18" fill="url(#brdbg)" stroke="#111" stroke-width="2"/><path d="M83 140 L83 35 Q83 25 90 28 L110 38 Q118 42 115 52 L100 80 Q95 88 88 82 L83 78" fill="url(#brdbg)" stroke="#111" stroke-width="2"/><line x1="55" y1="122" x2="55" y2="50" stroke="#DAA520" stroke-width="1.5"/><line x1="65" y1="122" x2="65" y2="50" stroke="#DAA520" stroke-width="1.5"/><line x1="75" y1="125" x2="75" y2="50" stroke="#DAA520" stroke-width="1.5"/><path d="M30 50 Q45 30 55 50 Q65 30 80 50" fill="none" stroke="#DAA520" stroke-width="2" opacity=".6"/><circle cx="55" cy="48" r="3" fill="#DAA520"/><circle cx="65" cy="48" r="3" fill="#DAA520"/><circle cx="75" cy="48" r="3" fill="#DAA520"/></g></svg>`,
Cleric:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="clrbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fff"/><stop offset="100%" stop-color="#bbb"/></linearGradient><filter id="glow"><feGaussianBlur stdDeviation="3" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g><circle cx="75" cy="90" r="60" fill="none" stroke="#ccc" stroke-width="1.5" opacity=".5"/><circle cx="75" cy="90" r="45" fill="none" stroke="#ddd" stroke-width="1"/><rect x="68" y="30" width="14" height="120" rx="3" fill="url(#clrbg)" stroke="#333" stroke-width="2"/><rect x="40" y="65" width="70" height="14" rx="3" fill="url(#clrbg)" stroke="#333" stroke-width="2"/><circle cx="75" cy="72" r="18" fill="none" stroke="#DAA520" stroke-width="2" filter="url(#glow)"/><circle cx="75" cy="72" r="5" fill="#DAA520" opacity=".7"/></g></svg>`,
Druid:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="drdbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#228B22"/><stop offset="100%" stop-color="#0a3a0a"/></linearGradient></defs><g><path d="M75 170 Q73 130 70 100 Q65 70 75 50 Q85 70 80 100 Q77 130 75 170" fill="#5a3a1a" stroke="#3a2a0a" stroke-width="2"/><path d="M75 50 Q30 20 40 5 Q55 15 75 50" fill="url(#drdbg)" stroke="#1a5a1a" stroke-width="1.5"/><path d="M75 50 Q120 20 110 5 Q95 15 75 50" fill="url(#drdbg)" stroke="#1a5a1a" stroke-width="1.5"/><path d="M75 70 Q20 50 35 30" fill="url(#drdbg)" stroke="#1a5a1a" stroke-width="1.5"/><path d="M75 70 Q130 50 115 30" fill="url(#drdbg)" stroke="#1a5a1a" stroke-width="1.5"/><path d="M70 90 Q35 80 45 60" fill="url(#drdbg)" stroke="#1a5a1a" stroke-width="1"/><path d="M80 90 Q115 80 105 60" fill="url(#drdbg)" stroke="#1a5a1a" stroke-width="1"/><circle cx="75" cy="50" r="8" fill="#90EE90" opacity=".4"/><path d="M60 165 Q75 155 90 165" stroke="#5a3a1a" stroke-width="3" fill="none"/></g></svg>`,
Fighter:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ftrbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#c0c0c0"/><stop offset="100%" stop-color="#555"/></linearGradient></defs><g><path d="M45 25 L75 10 L105 25 L100 90 L75 80 L50 90Z" fill="url(#ftrbg)" stroke="#222" stroke-width="2.5"/><line x1="75" y1="25" x2="75" y2="70" stroke="#333" stroke-width="2"/><line x1="58" y1="45" x2="92" y2="45" stroke="#333" stroke-width="2"/><rect x="70" y="85" width="10" height="70" rx="2" fill="#888" stroke="#333" stroke-width="2"/><rect x="55" y="145" width="40" height="14" rx="4" fill="#666" stroke="#333" stroke-width="2"/><circle cx="75" cy="152" r="4" fill="#999"/><path d="M52 30 L75 15 L98 30" fill="none" stroke="#DAA520" stroke-width="1.5"/></g></svg>`,
Monk:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="mnkbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#555"/><stop offset="100%" stop-color="#111"/></linearGradient></defs><g><circle cx="75" cy="90" r="60" fill="none" stroke="#444" stroke-width="2"/><circle cx="75" cy="90" r="55" fill="url(#mnkbg)" opacity=".15"/><path d="M75 30 A60 60 0 0 1 75 150" fill="#333" opacity=".5"/><circle cx="58" cy="70" r="14" fill="none" stroke="#888" stroke-width="2"/><circle cx="92" cy="110" r="14" fill="#444" stroke="#888" stroke-width="2"/><circle cx="58" cy="70" r="5" fill="#444"/><circle cx="92" cy="110" r="5" fill="#ddd"/><path d="M30 90 Q50 70 75 90 Q100 110 120 90" fill="none" stroke="#DAA520" stroke-width="2" opacity=".6"/><path d="M75 25 L75 18 M68 28 L63 22 M82 28 L87 22" stroke="#888" stroke-width="1.5" stroke-linecap="round"/></g></svg>`,
Paladin:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="palbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#DAA520"/><stop offset="100%" stop-color="#8B6914"/></linearGradient><filter id="palglow"><feGaussianBlur stdDeviation="2" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g><rect x="68" y="55" width="14" height="110" rx="2" fill="#aaa" stroke="#333" stroke-width="2"/><rect x="50" y="85" width="50" height="12" rx="2" fill="#aaa" stroke="#333" stroke-width="2"/><path d="M40 10 L75 2 L110 10 L105 55 L75 50 L45 55Z" fill="url(#palbg)" stroke="#333" stroke-width="2"/><path d="M55 15 L75 8 L95 15 L92 42 L75 38 L58 42Z" fill="none" stroke="#fff" stroke-width="1.5" opacity=".5"/><path d="M68 20 L75 55 L82 20" fill="none" stroke="#fff" stroke-width="1.5" opacity=".6"/><circle cx="75" cy="25" r="6" fill="#fff" opacity=".3" filter="url(#palglow)"/><path d="M55 165 L75 172 L95 165" fill="none" stroke="#DAA520" stroke-width="2"/></g></svg>`,
Ranger:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="rngbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#5a3a1a"/><stop offset="100%" stop-color="#2a1a0a"/></linearGradient></defs><g><path d="M75 15 Q25 90 75 165" fill="none" stroke="url(#rngbg)" stroke-width="4"/><path d="M75 15 Q125 90 75 165" fill="none" stroke="url(#rngbg)" stroke-width="4"/><line x1="28" y1="90" x2="122" y2="90" stroke="#5a3a1a" stroke-width="3"/><line x1="90" y1="10" x2="90" y2="170" stroke="#888" stroke-width="2.5"/><polygon points="90,5 85,22 95,22" fill="#8B0000" stroke="#600" stroke-width="1"/><path d="M86 160 L90 170 L94 160" fill="#666" stroke="#444" stroke-width="1"/><path d="M35 60 Q55 50 75 60" fill="none" stroke="#228B22" stroke-width="2" opacity=".5"/><path d="M75 60 Q95 50 115 60" fill="none" stroke="#228B22" stroke-width="2" opacity=".5"/></g></svg>`,
Rogue:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="rogbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#555"/><stop offset="100%" stop-color="#111"/></linearGradient></defs><g><path d="M75 10 L65 80 L55 170" fill="none" stroke="url(#rogbg)" stroke-width="3"/><path d="M75 10 L85 80 L95 170" fill="none" stroke="url(#rogbg)" stroke-width="3"/><polygon points="75,5 68,25 75,22 82,25" fill="#888" stroke="#333" stroke-width="1.5"/><rect x="60" y="75" width="30" height="18" rx="4" fill="#333" stroke="#555" stroke-width="1.5"/><circle cx="75" cy="84" r="3" fill="#DAA520"/><path d="M40 160 Q55 150 65 160" fill="none" stroke="#555" stroke-width="2" opacity=".5"/><path d="M85 160 Q95 150 110 160" fill="none" stroke="#555" stroke-width="2" opacity=".5"/><line x1="72" y1="80" x2="72" y2="88" stroke="#DAA520" stroke-width="1"/></g></svg>`,
Sorcerer:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="srcbg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#4B0082"/><stop offset="50%" stop-color="#8B008B"/><stop offset="100%" stop-color="#4B0082"/></linearGradient><filter id="srcglow"><feGaussianBlur stdDeviation="4" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g><circle cx="75" cy="90" r="50" fill="url(#srcbg)" opacity=".2" stroke="#8B008B" stroke-width="2"/><circle cx="75" cy="85" r="20" fill="#8B008B" opacity=".4" filter="url(#srcglow)"/><path d="M75 20 L78 35 L90 25 L82 38 L95 40 L82 45 L88 58 L75 48 L62 58 L68 45 L55 40 L68 38 L60 25 L72 35Z" fill="#DA70D6" stroke="#4B0082" stroke-width="1" filter="url(#srcglow)"/><path d="M40 130 Q55 110 75 130 Q95 110 110 130" fill="none" stroke="#DA70D6" stroke-width="2" opacity=".5"/><circle cx="75" cy="40" r="4" fill="#fff" opacity=".6"/></g></svg>`,
Warlock:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="wlkbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#1a0a2e"/><stop offset="100%" stop-color="#0a0a1a"/></linearGradient><filter id="wlkglow"><feGaussianBlur stdDeviation="3" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g><ellipse cx="75" cy="90" rx="50" ry="60" fill="url(#wlkbg)" stroke="#333" stroke-width="2" opacity=".5"/><ellipse cx="75" cy="85" rx="35" ry="25" fill="#1a0a2e" stroke="#4a2a6e" stroke-width="2"/><ellipse cx="75" cy="85" rx="18" ry="25" fill="#2a1a3e" stroke="#6a3a8e" stroke-width="1.5"/><circle cx="75" cy="85" r="8" fill="#8B008B" filter="url(#wlkglow)"/><circle cx="78" cy="82" r="3" fill="#DA70D6" opacity=".8"/><path d="M25 50 Q50 25 75 30 Q100 25 125 50" stroke="#4a2a6e" stroke-width="3" fill="none"/><path d="M25 125 Q50 150 75 145 Q100 150 125 125" stroke="#4a2a6e" stroke-width="3" fill="none"/><path d="M35 55 L30 45 M115 55 L120 45 M45 40 L42 30 M105 40 L108 30" stroke="#6a3a8e" stroke-width="2" stroke-linecap="round"/></g></svg>`,
Wizard:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="wizbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#1a237e"/><stop offset="100%" stop-color="#0a0a3e"/></linearGradient><filter id="wizglow"><feGaussianBlur stdDeviation="2" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g><path d="M55 170 L75 10 L95 170Z" fill="url(#wizbg)" stroke="#333" stroke-width="2"/><line x1="45" y1="150" x2="105" y2="150" stroke="#333" stroke-width="3"/><ellipse cx="75" cy="160" rx="35" ry="8" fill="none" stroke="#333" stroke-width="2"/><circle cx="75" cy="25" r="8" fill="#DAA520" filter="url(#wizglow)" opacity=".8"/><path d="M65 60 L85 60 M60 80 L90 80 M55 100 L95 100 M50 120 L100 120 M48 140 L102 140" stroke="#4a6a9e" stroke-width="1" opacity=".4"/><circle cx="75" cy="25" r="3" fill="#fff" opacity=".5"/><path d="M75 8 L77 18 M82 12 L80 20 M68 12 L70 20" stroke="#DAA520" stroke-width="1" opacity=".6"/></g></svg>`,
Artificer:`<svg viewBox="0 0 150 180" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="artbg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#B8860B"/><stop offset="100%" stop-color="#5a4306"/></linearGradient></defs><g><circle cx="75" cy="75" r="40" fill="none" stroke="url(#artbg)" stroke-width="3"/><circle cx="75" cy="75" r="30" fill="none" stroke="#B8860B" stroke-width="2"/><circle cx="75" cy="75" r="10" fill="#B8860B" opacity=".5"/><path d="M75 35 L75 25 M75 115 L75 125 M35 75 L25 75 M115 75 L125 75" stroke="#B8860B" stroke-width="3" stroke-linecap="round"/><path d="M55 55 L48 48 M95 55 L102 48 M55 95 L48 102 M95 95 L102 102" stroke="#B8860B" stroke-width="2" stroke-linecap="round"/><rect x="60" y="130" width="30" height="35" rx="3" fill="url(#artbg)" stroke="#333" stroke-width="2"/><rect x="55" y="125" width="40" height="10" rx="2" fill="#B8860B" stroke="#333" stroke-width="1.5"/></g></svg>`
};

// ==================== PICK FROM BACKGROUND ====================
function pickFromBackground(field, bgKey) {
    if (!currentChar || !currentChar.background) { alert('Select a background first'); return; }
    const bg = currentChar.background;
    const data = window.BG_PERSONALITY_DATA && window.BG_PERSONALITY_DATA[bg];
    if (!data || !data[bgKey]) { alert('No data for ' + bg); return; }
    const options = data[bgKey];
    let html = '<div style="max-height:400px;overflow:auto">';
    options.forEach((opt, i) => {
        html += '<div class="pick-option" onclick="selectBgOption(\'' + field + '\',' + i + ',\'' + bgKey + '\')" style="padding:8px;border-bottom:1px solid #ddd;cursor:pointer">' + (i+1) + '. ' + opt + '</div>';
    });
    html += '</div>';
    showModal(bg + ' — ' + field.replace(/([A-Z])/g,' $1').trim(), html);
}
function selectBgOption(field, idx, bgKey) {
    const data = window.BG_PERSONALITY_DATA[currentChar.background];
    if (data && data[bgKey] && data[bgKey][idx]) {
        currentChar[field] = data[bgKey][idx];
        saveCharacter(currentChar);
        render();
    }
    closeModal();
}

// ==================== HP CHANGE POPUP ====================
function openHpChange(mode) {
    const title = mode === 'heal' ? '➕ Heal' : '➖ Damage';
    const values = [1,2,3,4,5,6,7,8,9,10,12,15,20,25,30,40,50];
    let html = '';
    if (mode === 'heal') {
        html += '<div style="display:flex;justify-content:center;gap:8px;padding:8px 12px 0"><button class="hp-mode-btn hp-mode-active" id="hp-mode-heal" onclick="switchHpMode(\'heal\')">❤️ Heal HP</button><button class="hp-mode-btn" id="hp-mode-temp" onclick="switchHpMode(\'temp\')">🛡️ Temp HP</button></div>';
    }
    html += '<div style="display:flex;flex-wrap:wrap;gap:6px;justify-content:center;padding:12px" id="hp-grid">';
    values.forEach(v => {
        html += '<button style="width:52px;height:44px;font-size:1.1rem;font-weight:700;cursor:pointer;border:1px solid #ddd;border-radius:6px;background:#fff" onclick="applyHpChange(window._hpMode||\''+mode+'\','+v+')">' + v + '</button>';
    });
    html += '</div>';
    window._hpMode = mode;
    showModal(title, html);
}
function switchHpMode(mode) {
    window._hpMode = mode;
    const healBtn = document.getElementById('hp-mode-heal');
    const tempBtn = document.getElementById('hp-mode-temp');
    if (healBtn) healBtn.className = 'hp-mode-btn' + (mode==='heal'?' hp-mode-active':'');
    if (tempBtn) tempBtn.className = 'hp-mode-btn' + (mode==='temp'?' hp-mode-active':'');
}
function applyHpChange(mode, val) {
    if (!val || val <= 0) { closeModal(); return; }
    if (mode === 'temp') {
        currentChar.hpTemp = Math.max(currentChar.hpTemp || 0, val);
    } else if (mode === 'heal') {
        const wasAtZero = currentChar.hpCurrent === 0;
        currentChar.hpCurrent = Math.min(currentChar.hpMax, currentChar.hpCurrent + val);
        if (wasAtZero && currentChar.hpCurrent > 0) {
            currentChar.deathSuccess = [false,false,false];
            currentChar.deathFail = [false,false,false];
        }
    } else {
        let remaining = val;
        if (currentChar.hpTemp > 0) {
            const absorbed = Math.min(currentChar.hpTemp, remaining);
            currentChar.hpTemp -= absorbed;
            remaining -= absorbed;
        }
        currentChar.hpCurrent = Math.max(0, currentChar.hpCurrent - remaining);
    }
    saveCharacter(currentChar);
    closeModal();
    render();
}

// ==================== NUMBER PICKER POPUP ====================
function openNumberPicker(field, label, min, max, current) {
    let html = '<div style="display:flex;flex-wrap:wrap;gap:6px;justify-content:center;padding:12px">';
    for (let i = min; i <= max; i++) {
        const selected = i === current ? 'font-weight:700;border:2px solid #000' : '';
        html += '<button style="width:48px;height:40px;font-size:1rem;cursor:pointer;border:1px solid #ddd;border-radius:4px;background:#fff;'+selected+'" onclick="updateField(\''+field+'\','+i+');closeModal();render()">'+i+'</button>';
    }
    html += '</div>';
    showModal('Select ' + label, html);
}
function openLevelPicker() {
    let html = '<div style="display:flex;flex-wrap:wrap;gap:6px;justify-content:center;padding:12px">';
    for (let i = 1; i <= 20; i++) {
        const selected = i === currentChar.level ? 'font-weight:700;border:2px solid #000' : '';
        html += '<button style="width:48px;height:40px;font-size:1rem;cursor:pointer;border:1px solid #ddd;border-radius:4px;background:#fff;'+selected+'" onclick="updateField(\'level\','+i+');updateProfBonus();closeModal()">'+i+'</button>';
    }
    html += '</div>';
    showModal('Select Level', html);
}
function openXpPicker() {
    const presets = [0,300,900,2700,6500,14000,23000,34000,48000,64000,85000,100000,120000,140000,165000,195000,225000,265000,305000,355000];
    let html = '<div style="padding:12px"><div style="margin-bottom:12px;text-align:center"><input type="number" id="xp-input-val" value="'+currentChar.xp+'" style="font-size:1.2rem;width:120px;text-align:center;padding:6px" min="0"><br><button class="picker-btn-dark" style="padding:6px 16px;margin-top:8px;background:#333;color:#fff;border:1px solid #333;border-radius:4px;cursor:pointer" onclick="updateField(\'xp\',+(document.getElementById(\'xp-input-val\').value)||0);closeModal();render()">Set XP</button></div>';
    html += '<div style="font-size:.75rem;color:#666;margin-bottom:6px;text-align:center">Level thresholds:</div><div style="display:flex;flex-wrap:wrap;gap:4px;justify-content:center">';
    presets.forEach((xp,i) => {
        html += '<button style="padding:4px 8px;font-size:.75rem;cursor:pointer;border:1px solid #ddd;border-radius:3px;background:#fff" onclick="updateField(\'xp\','+xp+');closeModal();render()">Lvl '+(i+1)+': '+xp.toLocaleString()+'</button>';
    });
    html += '</div></div>';
    showModal('Set XP', html);
}

// ==================== CURRENCY VISIBILITY ====================
function getCurrencyExpanded() {
    try { return localStorage.getItem('mcmt_currency_expanded') === 'true'; } catch { return false; }
}
function toggleCurrencyVisibility() {
    const current = getCurrencyExpanded();
    localStorage.setItem('mcmt_currency_expanded', current ? 'false' : 'true');
    render();
}
function renderTrackerCoins(c) {
    const expanded = getCurrencyExpanded();
    const coins = expanded ? ['cp','sp','ep','gp','pp'] : ['gp'];
    return coins.map(coin => `<span class="tb-item tb-coin-item">
        <span class="coin-counter-icon">${COIN_ICONS[coin]}</span>
        <span class="tb-coin-label">${coin.toUpperCase()}</span>
        <button class="tb-coin-btn" onclick="event.stopPropagation();adjustCoin('${coin}',-1)">−</button>
        <strong id="coin-${coin}">${c[coin]}</strong>
        <button class="tb-coin-btn" onclick="event.stopPropagation();adjustCoin('${coin}',1)">+</button>
    </span>`).join('');
}

// ==================== COIN PICKER ====================
function adjustCoin(coin, delta) {
    if (!currentChar) return;
    currentChar[coin] = Math.max(0, (currentChar[coin]||0) + delta);
    saveCharacter(currentChar);
    const el = document.getElementById('coin-'+coin);
    if (el) el.textContent = currentChar[coin];
}

// ==================== CANTRIP QUICKCAST ====================
function setCantripSlot(idx, spellName) {
    if (!currentChar) return;
    if (!currentChar.cantripSlots) currentChar.cantripSlots = ['','','',''];
    while (currentChar.cantripSlots.length < 4) currentChar.cantripSlots.push('');
    currentChar.cantripSlots[idx] = spellName;
    saveCharacter(currentChar);
    if (spellName) openCastSpellPopup(spellName);
}


function renderTreasureSection(c) {
    const expanded = getCurrencyExpanded();
    const coins = expanded ? ['cp','sp','ep','gp','pp'] : ['gp'];
    return '<div class="coin-counter-list">' + coins.map(coin => 
        '<div class="coin-counter-row">' +
        '<span class="coin-counter-icon">' + COIN_ICONS[coin] + '</span>' +
        '<span class="coin-counter-label">' + coin.toUpperCase() + '</span>' +
        '<button class="coin-counter-btn" onclick="adjustCoin(\'' + coin + '\',-1)">−</button>' +
        '<span class="coin-counter-val" id="treasure-' + coin + '">' + c[coin] + '</span>' +
        '<button class="coin-counter-btn" onclick="adjustCoin(\'' + coin + '\',1)">+</button>' +
        '</div>'
    ).join('') + '</div>';
}

// ==================== CAST SPELL SYSTEM ====================
function openCastSpellPopup(spellName, overrideLevel) {
    const spell = SPELLS.find(s => s.name === spellName);
    if (!spell) { openSpellDetail(spellName); return; }
    const c = currentChar;
    if (!c) return;
    const access = SPELL_ACCESS[spell.name.toLowerCase()] || {};
    const classes = (access.classes || []).join(', ') || 'None listed';
    const isCantrip = spell.level === 0;
    const overlay = $('#spell-detail-overlay');
    const title = $('#spell-detail-title');
    const body = $('#spell-detail-body');
    title.textContent = spell.name;

    // Build cast level options for leveled spells
    let castButtons = '';
    if (isCantrip) {
        castButtons = `<div class="cast-actions"><button class="btn btn-primary cast-btn" onclick="doCastSpell('${esc(spell.name)}',0)">🎯 Cast Cantrip</button></div>`;
    } else {
        const castLevel = overrideLevel || spell.level;
        let slotOptions = '';
        for (let lvl = spell.level; lvl <= 9; lvl++) {
            const slot = c.spellSlots[lvl];
            if (slot && slot.max > 0) {
                const avail = slot.max - slot.used;
                slotOptions += `<button class="btn ${lvl===castLevel?'btn-primary':'btn-secondary'} cast-btn" onclick="doCastSpell('${esc(spell.name)}',${lvl})" ${avail<=0?'disabled title="No slots remaining"':''}>${lvl}${['st','nd','rd'][lvl-1]||'th'} (${avail}/${slot.max})</button> `;
            }
        }
        // Also check pact slots
        if (c.pactSlots && c.pactSlots.max > 0 && spell.level <= c.pactSlots.level) {
            const pavail = c.pactSlots.max - c.pactSlots.used;
            slotOptions += `<button class="btn btn-secondary cast-btn" onclick="doCastSpellPact('${esc(spell.name)}')" ${pavail<=0?'disabled title="No pact slots remaining"':''}>Pact (${pavail}/${c.pactSlots.max})</button> `;
        }
        // Add ritual casting button if applicable
        let ritualBtn = '';
        if (spell.ritual) {
            const RITUAL_CASTERS = ['Wizard','Cleric','Druid','Bard','Artificer'];
            const charClass = c.charClass || '';
            const charClasses = c.classLevels ? Object.keys(c.classLevels) : [charClass];
            const canRitual = charClasses.some(cl => RITUAL_CASTERS.includes(cl));
            if (canRitual) {
                ritualBtn = ` <button class="btn btn-secondary cast-btn ritual-cast-btn" onclick="doCastRitual('${esc(spell.name)}')">📜 Ritual</button> `;
            }
        }
        castButtons = slotOptions || ritualBtn ? `<div class="cast-actions"><div class="cast-label">Cast using slot:</div><div class="cast-buttons">${slotOptions}${ritualBtn}</div></div>` : '<div class="cast-actions"><em>No spell slots available</em></div>';
    }

    body.innerHTML = `
        <div class="spell-detail-grid">
            <div class="sd-row"><strong>Level:</strong> ${spell.level === 0 ? 'Cantrip' : spell.level}</div>
            <div class="sd-row"><strong>School:</strong> ${esc(spell.school)}</div>
            <div class="sd-row"><strong>Casting Time:</strong> ${esc(spell.castingTime)}</div>
            <div class="sd-row"><strong>Range:</strong> ${esc(spell.range)}</div>
            <div class="sd-row"><strong>Components:</strong> ${esc(spell.components)}</div>
            <div class="sd-row"><strong>Duration:</strong> ${esc(spell.duration)}</div>
            ${spell.concentration ? '<div class="sd-row"><span class="badge badge-info">Concentration</span></div>' : ''}
            ${spell.ritual ? '<div class="sd-row"><span class="badge badge-info">Ritual</span></div>' : ''}
        </div>
        <div class="sd-description"><strong>Description:</strong><p>${esc(spell.description || 'No description available.')}</p></div>
        ${spell.higherLevel ? `<div class="sd-higher"><strong>At Higher Levels:</strong><p>${esc(spell.higherLevel)}</p></div>` : ''}
        ${castButtons}
    `;
    overlay.style.display = 'flex';
}

function doCastSpell(spellName, level) {
    const c = currentChar;
    if (!c) return;
    const spell = SPELLS.find(s => s.name === spellName);
    if (!spell) return;

    if (level > 0) {
        const slot = c.spellSlots[level];
        if (!slot || slot.used >= slot.max) { alert('No level ' + level + ' spell slots remaining!'); return; }
        slot.used++;
    }

    // Handle concentration
    if (spell.concentration) {
        if (c.concentratingOn && c.concentratingOn !== spellName) {
            if (!confirm(`You are concentrating on "${c.concentratingOn}". Replace with "${spellName}"?`)) {
                if (level > 0) c.spellSlots[level].used--; // refund
                return;
            }
        }
        c.concentratingOn = spellName;
    }

    saveCharacter(c);
    closeSpellDetail();
    render();
}

function doCastSpellPact(spellName) {
    const c = currentChar;
    if (!c || !c.pactSlots) return;
    const spell = SPELLS.find(s => s.name === spellName);
    if (!spell) return;
    if (c.pactSlots.used >= c.pactSlots.max) { alert('No pact slots remaining!'); return; }
    c.pactSlots.used++;

    if (spell.concentration) {
        if (c.concentratingOn && c.concentratingOn !== spellName) {
            if (!confirm(`You are concentrating on "${c.concentratingOn}". Replace with "${spellName}"?`)) {
                c.pactSlots.used--;
                return;
            }
        }
        c.concentratingOn = spellName;
    }

    saveCharacter(c);
    closeSpellDetail();
    render();
}

// ==================== DARK MODE TOGGLE ====================
function initTheme() {
    const saved = localStorage.getItem('mcmt_theme');
    const mode = saved || 'dark';
    document.body.className = mode + '-mode';
    updateThemeIcon(mode);
}
function toggleTheme() {
    const isDark = document.body.classList.contains('dark-mode');
    const newMode = isDark ? 'light' : 'dark';
    document.body.className = newMode + '-mode';
    localStorage.setItem('mcmt_theme', newMode);
    updateThemeIcon(newMode);
}
function updateThemeIcon(mode) {
    const btn = document.getElementById('theme-toggle');
    if (btn) btn.textContent = mode === 'dark' ? '☀️' : '🌙';
}

// ==================== INIT ====================
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    render();
    document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeModal(); closeShortRest(); closeSpellDetail(); const ip=$('#info-popup-overlay'); if(ip)ip.style.display='none'; } });
});